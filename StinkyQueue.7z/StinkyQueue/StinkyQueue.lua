function StinkyQueue_OnLoad()
	this:RegisterEvent("CHAT_MSG_ADDON");
	this:RegisterEvent("UPDATE_BATTLEFIELD_STATUS");
	StinkyDiabled=0;
end

function StinkyQueueOnEvent()
	if (event=="CHAT_MSG_ADDON") then
		if (arg1=="StinkyQ" and StinkyQueueDisable()==0) then
			local lastBGQueue = GetBattlefieldInfo();
			if (lastBGQueue~="Alterac Valley" and not (arg2=="LeaveQueue ab" or arg2=="LeaveQueue wsg" or arg2=="LeaveQueue av")) then
				DEFAULT_CHAT_FRAME:AddMessage("A StinkyQueue function has been called but your last BG window was not Alterac Valley, or you are out of range. Please open the AV Battlefield Window.",1.0, 0.35, 0.0);
			else
				arg2, arg22, arg222 = strsplit(" ",arg2);

				if (arg2=="Queue") then
					JoinBattlefield(0);
				elseif (arg2=="LeaveQueue") then
					StinkyQueueLeaveQueue(-1,arg22)
				elseif (arg2=="SoloQ") then
					StinkyQueueLeaveQueue(arg22,"av");
					StinkyQueueSoloQueue(arg22);
					avRequeued=arg22;
				end
				if (arg222 ~= nil) then
					DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: You are using an old version of StinkyQueue. Please update at www.curse-gaming.com.",1.0, 1.0, 0.75);
				end
			end
		end
	elseif (event=="UPDATE_BATTLEFIELD_STATUS") then
		for i=1, MAX_BATTLEFIELD_QUEUES do
			local bfs1,bfs2,bfs3=GetBattlefieldStatus(i);
			if (bfs1=="confirm" and bfs2=="Alterac Valley") then
				if (avRequeued==bfs3) then
					avReqExtra = "Requeued - ";
					avRequeued=-1;
				else
					avReqExtra="";
				end
				StinkyQueueRaidSpam(avReqExtra..bfs3,nil);

			end
		end

	end
end

function StinkyQueueLeaveQueue(msg,bg)
	StinkyQueueBattleGroundNames={["av"]="Alterac Valley", ["ab"]="Arathi Basin", ["wsg"]="Warsong Gulch"};
	local StinkyDidGetQueuedOut = 0;
	for i=1, MAX_BATTLEFIELD_QUEUES do
		local x,y,z=GetBattlefieldStatus(i);
		if (tonumber(msg)~=z and y==StinkyQueueBattleGroundNames[bg] and x~="active") then
			ShowBattlefieldList(i)
			AcceptBattlefieldPort(i,nil);
			StinkyDidGetQueuedOut = 1;
		end
	end
	if (StinkyDidGetQueuedOut==0) then
		DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: Did not Leave "..StinkyQueueBattleGroundNames[bg].." Queue.",1.0, 1.0, 0.75);
	end
end

function StinkyQueueSoloQueue(msg)
	for i=1, GetNumBattlefields() do
		if(GetBattlefieldInstanceInfo(i)==tonumber(msg)) then
			JoinBattlefield(i);
			DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: SoloQueued for - "..msg,1.0, 1.0, 0.75);
		end
	end
end

function StinkyQueueTest()
	local lastBGQueue = GetBattlefieldInfo();
	if (lastBGQueue~="Alterac Valley") then
		DEFAULT_CHAT_FRAME:AddMessage("A StinkyQueue function has been called but your last BG window was not Alterac Valley, please open the AV Battlefield Window.",1.0, 0.35, 0.0);
	else
		DEFAULT_CHAT_FRAME:AddMessage("Your last Battleground Window was Alterac Valley and appears valid.  You should recieve SQ requests successfully.",1.0, 0.35, 0.0);
	end

end

function StinkyQueueRaidSpam(msg,location)
	msg="StinkyQueue: "..msg;
	if (location == nil) then
		if (GetNumRaidMembers()<6) then
			SendChatMessage(msg,"PARTY");
		else
			SendChatMessage(msg,"RAID");
		end
	else
		SendChatMessage(msg,location);
	end
end


function StinkyQueueDisable(msg)
	if (msg== 1) then
		if (StinkyDiabled == 1) then
			StinkyDiabled = 0;
			DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: Enabled!",1.0, 1.0, 0.75);
		else
			StinkyDiabled = 1;
			DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: Disabled!",1.0, 1.0, 0.75);
		end
	else
		return StinkyDiabled
	end
end

function StinkyQueueQueue(msg)
	if (strfind(msg, " ", 1)~=nil) then
		msg = strlower(msg);
		msg2 = strsub(msg,strfind(msg, " ", 1)+1,strlen(msg));
		msg = strsub(msg,1,strfind(msg, " ", 1)-1);
	end
	if (msg=="") then
		DEFAULT_CHAT_FRAME:AddMessage("Kazthok's AV Queuer-er-er Command List",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq                 - This Help",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq queue       [q] - Force everone to join battleground at the same time.",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq leavequeue #[lq]- Force Everyone to Leave Queue, #= ab,av,wsg.  None is defaulted AV.",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq soloqueue # [sq]- Force those with out BG# to leave theirs and single queue for it.  Including those with out a BG confirm box.",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq groupqueue  [gq]- Queues as a group what your last BG window was.",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq disable     [d] - Toggles SQ. This allows you to throw commands but disables you from receiving any.",1.0, 1.0, 0.75);
		DEFAULT_CHAT_FRAME:AddMessage("/sq test        [t] - Test to see if your BG window is valid for AV.",1.0, 1.0, 0.75);

	elseif ((msg=="queue" or msg=="q")) then
		if (GetNumRaidMembers()<6) then
			SendAddonMessage( "StinkyQ", "Queue", "PARTY" );
		elseif (GetNumRaidMembers()==0) then
			JoinBattlefield(0);
		else
			SendAddonMessage( "StinkyQ", "Queue", "RAID" );
		end
		StinkyQueueRaidSpam("Initial Queue","raid_warning");
	elseif (msg=="v" or msg=="version") then
		if (GetNumRaidMembers()<6) then
			SendAddonMessage( "StinkyQ", "VersionCheck", "PARTY" );
		elseif (GetNumRaidMembers()==0) then
			JoinBattlefield(0);
		else
			SendAddonMessage( "StinkyQ", "VersionCheck", "RAID" );
		end
	elseif ((msg=="lq" or msg=="leavequeue") ) then
		if (msg2==nil) then
			msg2="av";
		elseif (msg2~="av" and msg2~="ab" and msg2~="wsg") then
			DEFAULT_CHAT_FRAME:AddMessage("/sq leavequeue # | Invalid #: av,ab,or wsg only, blank for av default.  Defaulting to AV.",1.0, 1.0, 0.75);
			msg2="av";
		end
		if (GetNumRaidMembers()<6) then
			SendAddonMessage( "StinkyQ", "LeaveQueue "..msg2, "PARTY" );
		elseif (GetNumRaidMembers()==0) then
			StinkyQueueLeaveQueue(-1);
		else
			SendAddonMessage( "StinkyQ", "LeaveQueue "..msg2, "RAID" );
		end
		StinkyQueueRaidSpam("Forcing LeaveQueue","raid_warning");
	elseif ((msg=="soloqueue" or msg=="sq")) then
		if (msg2~=nil) then
			if (GetNumRaidMembers()<6) then
				SendAddonMessage( "StinkyQ", "SoloQ "..msg2, "PARTY" );
			elseif (GetNumRaidMembers()==0) then
				StinkyQueueSoloQueue(msg2);
			else
				SendAddonMessage( "StinkyQ", "SoloQ "..msg2, "RAID" );
			end
			StinkyQueueRaidSpam("Forcing Solo Queue - "..msg2,"raid_warning");
		else
			DEFAULT_CHAT_FRAME:AddMessage("Error, no BG # specified.",1.0, 1.0, 0.75);
			DEFAULT_CHAT_FRAME:AddMessage("/sq soloqueue # [sq]- Force those with out BG# to leave theirs and single queue for it.  Including those with out a BG confirm box.",1.0, 1.0, 0.75);
		end
	elseif ((msg=="groupqueue" or msg=="gq")) then
		JoinBattlefield(0, 1);
		StinkyQueueRaidSpam("Group Queue","raid_warning");
	elseif (msg=="t" or msg=="test") then
		if (StinkyQueueDisable()==1) then
			DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: SQ is currently disabled.",1.0, 1.0, 0.75);
		else
			StinkyQueueTest();
		end
	elseif (msg=="d" or msg=="disable") then
		StinkyQueueDisable(1);
	else
		DEFAULT_CHAT_FRAME:AddMessage("StinkyQueue: Invalid Command or you do not have permission to do that.",1.0, 1.0, 0.75);
	end
	msg2 = nil;
end


SLASH_STINKYQUEUE1 = "/stinkyqueue";
SLASH_STINKYQUEUE2 = "/stinkyq";
SLASH_STINKYQUEUE3 = "/sq";
SLASH_STINKYQUEUE4 = "/stinkpalm";
SlashCmdList["STINKYQUEUE"] = StinkyQueueQueue;