	------Kazthok's Uber Group AV Queue Bullshit Addon------		
Queues a group (or raid) for AV at the same instant, increasing the chance you all get the same queue.
Also provides group leave queue, and group single queue (if you didn't get everyone's) functionality.

	/stinkyqueue
	/stinkyq
	/sq
	/stinkpalm


/sq                 - This Help
/sq queue       [q] - Force everone to join battleground at the same time.
/sq leavequeue #[lq]- Force Everyone to Leave Queue, #= ab,av,wsg.  None is defaulted AV.
/sq soloqueue # [sq]- Force those with out BG# to leave theirs and single queue for it.  Including those with out a BG confirm box.
/sq groupqueue  [gq]- Queues as a group what your last BG window was.
/sq disable     [d] - Toggles SQ. This allows you to throw commands but disables you from receiving any.
/sq test        [t] - Test to see if your BG window is valid for AV.