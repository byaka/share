# -*- coding: utf-8 -*-
from gevent import monkey; monkey.patch_all()

import sys, re, datetime
from datetime import datetime, timedelta
from time import mktime
sys.path.append('/home/python/libs/')
sys.path.append('/home/python/')
sys.path.append('/home/python/cycles/')
sys.path.append('/home/python/apiFuncs')
sys.path.append('/home/python/api/')
from functionsex import *
from flask import Flask,request
from flask_cors import CORS, cross_origin
from globals import *
from func import *
from sqlWrap import _sql
from returnerConnectors import *

from returnerApi_new import ReturnerApiWithCache_contacts, ReturnerApi_getVisitsData

app = Flask('returner')
CORS(app, resources={r"*": {"origins": "*"}})

def cleanInData(s, col=False):
   if not s: return s
   if col in ('url','siteName'): replaceArr=('\\','%','!','"',"'")
   else: replaceArr=('\\','//','%','!','"',"'")
   s=s.strip()
   for r in replaceArr:
      s=s.replace(r,'')
   # s=s.replace("'",'').replace("\\",'').replace("//",'').replace("%",'').replace("!",'').replace('"','')
   return s

def getParams(request):
   params={}
   if request.method == 'POST':
      params={k:v for k,v in request.form.iteritems()}
   else:
      # print request.args
      for k in request.args:
         params[k]=request.args.get(k)
   params={k:cleanInData(v,k) for k,v in params.iteritems()}
   #!сделать проверку, чтобы siteId было только из цифр
   return params

def checkParams(params, keys):
   #!сделать проверку на кавычки и на то, что siteId всегда должен быть числом
   for k in keys:
      if k not in params or params[k]=='': return False
   return True

def getUserByToken(token):
   #!сделать защиту от mysql Injection
   if '"' in token: return False
   if not token: return False
   userId=mysqlSelectOne('SELECT userId FROM buber.sysTokens WHERE token="%s" and project="returner"'%token, '_buber_')
   return userId['userId']

domainCache={}
def _url2siteId(url,siteName=False, userId=0):
   serverForNew='144.76.43.233'
   dbPostfixForNew='3'
   if 'http://' not in url and 'https://' not in url: url='http://'+url
   # t=url.replace('https://','http://')
   # print t
   urlArr=urlsplit(url)
   #перебираем различные варианты написания домена (http://www.___, http://___, www.___. ___)
   if not urlArr.netloc or len(urlArr.netloc)<3: return False
   s=urlArr.netloc[4:] if urlArr.netloc[:4]=='www.' else urlArr.netloc
   domainVariant=[]
   domainVariant+=['%s'%s, '%s/'%s]
   domainVariant+=['www.%s'%s, 'www.%s/'%s]
   domainVariant+=['https://%s'%s, 'https://%s/'%s]
   domainVariant+=['https://www.%s'%s, 'https://www.%s/'%s]
   domainVariant+=['http://%s'%s, 'http://%s/'%s]
   domainVariant+=['http://www.%s'%s, 'http://www.%s/'%s]
   _siteArr=None
   for s in domainVariant:
     if sha1(s) not in domainCache: continue
     _siteArr=domainCache[sha1(s)]
     break
   if not _siteArr:
     _siteArr=mysqlSelectOne('SELECT siteId, siteURL, siteUrlSha, userId, server, dbPostfix, siteType FROM tblsites WHERE %s'%(' OR '.join(['siteUrlSha="%s"'%sha1(s) for s in domainVariant])), '_buber_')
   if not _siteArr:
     url='%s://%s'%(urlArr.scheme, urlArr.netloc)
     _siteArr={'siteURL':url, 'siteName':url if not siteName else siteName, 'siteUrlSha':sha1(url), 'userId':userId, 'server':serverForNew, 'dbPostfix':dbPostfixForNew, 'siteType':''}
     _siteArr['siteId']=mysqlInsert(_siteArr, 'tblsites', '_buber_')
     if not _siteArr['siteId']: print '!! ERROR adding site', _siteArr
     _siteArr['notExist']=True
   if _siteArr['siteUrlSha'] not in domainCache: #записываем в кеш
     domainCache[_siteArr['siteUrlSha']]=dict([[k, v] for k,v in _siteArr.items() if k not in ['notExist']])
   return _siteArr

@app.route('/ping', methods=['GET','POST'])
def returner_ping():
   print 'дернули ping %s'%strEx(datetime.datetime.now())
   return 'pong'

@app.route('/auth', methods=['GET', 'POST'])
def returner_login():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   # #обрабатываем ошибки
   if not params['mail'] or not params['pass']: res={'status':False, 'code':1001, 'error':'Не передано одно из обязательных полей'}
   if params['mail']=='' or params['pass']=='': res={'status':False, 'code':1002, 'error':'Одно из обязательных полей - пустое'}
   if res['status'] is False: return reprEx(res)
   #ищем пользователя
   sel=mysqlSelectOne('SELECT userId, userMail, userName, userTel FROM sysUsers WHERE userMail="%s" AND userPass="%s"'%(params['mail'], md5(params['pass'])),'_buber_')
   if not sel:
      res={'status':False, 'code':1003, 'error':'Пользователь не найден или неверная пара логин/пароль'}
      return reprEx(res)
   userArr={'userId':int(sel['userId']), 'mail':sel['userMail'],'name':sel['userName'],'phone':sel['userTel']}
   #ищем по токенам
   tokens=mysqlSelect('SELECT userId, siteId, token, rights  FROM buber.sysTokens WHERE userId=%s and project="returner"'%userArr['userId'], '_buber_')
   if tokens:
      userArr['token']=tokens[0]['token']
      userArr['siteIds']=[k['siteId'] for k in tokens if k['siteId']!=0]
      res['data']=userArr
   else: #достаём права
      userArr['token']=pbkdf2(randomEx(), ''.join([params['mail'] for i in xrange(numEx(randomEx(100)))]))
      userArr['siteIds']=[]
      rights=mysqlSelect('SELECT masterUserId, slaveSiteId FROM buber.sysRights WHERE masterUserId=%s and project="returner"'%userArr['userId'], '_buber_')
      if rights: #есть права, нужно добавить в sysTokens
         for k in rights:
            if strEx(k['slaveSiteId'])==0: continue
            insArr={'userId':userArr['userId'], 'siteId':k['slaveSiteId'], 'token':userArr['token'], 'rights':'w', 'project':'returner'}
            mysqlInsert(insArr,'sysTokens','_buber_')
            userArr['siteIds'].append(k['slaveSiteId'])
      else:
         insArr={'userId':userArr['userId'], 'siteId':0, 'token':userArr['token'], 'rights':'r', 'project':'returner'}
         mysqlInsert(insArr,'sysTokens','_buber_')
      res['data']=userArr
   res['status']=True
   return reprEx(res)

@app.route('/reg', methods=['GET', 'POST'])
def returner_reg():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['name','mail','phone','pass']):
      return reprEx({'status':False, 'code':2001, 'error':'Не передано одно из обязательных полей'})
   #ищем пользователя
   userArr=mysqlSelectOne('SELECT userId, userMail, userPass FROM sysUsers WHERE userMail="%s"'%params['mail'],'_buber_')
   if userArr:
      if userArr['userPass']!=md5(params['pass']):
         return reprEx({'status':False, 'code':2002, 'error':'Пользователь с таким email уже существует и пароли не совпадают'})
   else: #создаём пользователя
      insArr={'userMail':params['mail'], 'userName':params['name'], 'userTel':params['phone'], 'userPass':md5(params['pass'])}
      userId=mysqlInsert(insArr,'sysUsers', '_buber_')
      userArr={'userId':userId, 'userMail':insArr['userMail']}
   #теперь разбираемся с токеном
   tokens=mysqlSelect('SELECT userId, siteId, token, rights  FROM buber.sysTokens WHERE userId=%s and project="returner"'%userArr['userId'], '_buber_')
   if tokens: userArr['token']=tokens[0]['token']
   else:
      userArr['token']=pbkdf2(randomEx(), ''.join([params['mail'] for i in xrange(numEx(randomEx(100)))]))
      insArr={'userId':userArr['userId'], 'siteId':0, 'token':userArr['token'], 'rights':'w', 'project':'returner'}
      mysqlInsert(insArr,'sysTokens','_buber_')
   res['data']={'mail':userArr['userMail'],'token':userArr['token'],'userId':userArr['userId']}
   res['status']=True
   returnerMailReg(userId=userArr['userId'])
   return reprEx(res)

@app.route('/add', methods=['GET', 'POST'])
def returner_siteAdd():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token','url','siteName','confirmMail', 'subdomains']): return reprEx({'status':False, 'code':3001, 'error':'Не передано одно из обязательных полей'})
   #проверяем на токен
   userArr={'token':params['token']}
   userId=getUserByToken(params['token'])
   if not userId or userId==0: return reprEx({'status':False, 'code':3002, 'error':'Токен не найден'})
   userArr['userId']=userId
   #разбираемся с сайтом
   if not re.match('^(http[|s]?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$',params['url']):
      return reprEx({'status':False, 'code':3003, 'error':'Не удалось добавить сайт. Неверный url'})
   siteArr=_url2siteId(params['url'], params['siteName'], userId=userArr['userId'])
   if not siteArr or not len(siteArr): return reprEx({'status':False, 'code':3003, 'error':'Не удалось добавить сайт'})
   #ищем данный сайт у другого пользователя
   sel=mysqlSelectOne('SELECT * FROM sysRights WHERE masterUserId!="%s" AND slaveSiteId="%s" AND project="returner"'%(userArr['userId'], siteArr['siteId']),'_buber_')
   if sel: return reprEx({'status':False, 'code':3004, 'error':'Данный сайт уже добавлен другим пользователем. Обратитесь в службу поддержки.'})
   #разбираемся с sysRights
   rightsArr=mysqlSelectOne('SELECT * FROM sysRights WHERE masterUserId="%s" AND slaveSiteId="%s" AND project="returner"'%(userArr['userId'], siteArr['siteId']),'_buber_')
   if not rightsArr:
      insArr={'masterUserId':userArr['userId'], 'slaveSiteId':siteArr['siteId'], 'project':'returner'}
      mysqlInsert(insArr, 'sysRights', '_buber_')
   #разбираемся с sysTokens
   if not mysqlSelectOne('SELECT rights FROM sysTokens WHERE userId="%s" and token="%s" and siteId="%s" and project="returner"'%(userArr['userId'], userArr['token'], siteArr['siteId']), '_buber_'):
      insArr={'userId':userArr['userId'], 'siteId':siteArr['siteId'], 'token':userArr['token'], 'rights':'w', 'project':'returner'}
      mysqlInsert(insArr,'sysTokens','_buber_')
   #заносим инфу о сайте в returner.sites
   if not mysqlSelectOne('SELECT * FROM returner.sites WHERE siteId=%s'%siteArr['siteId'],'_buber4_'):
      insArr={'userId':userArr['userId'], 'siteId':siteArr['siteId'], 'confirmMail':params['confirmMail'], 'subdomains':1 if params['subdomains'] and params['subdomains'] is True else 0}
      print_r(insArr)
      mysqlInsert(insArr,'returner.sites','_buber4_')
   res['data']={'siteId':siteArr['siteId']}
   res['status']=True
   returnerSiteAdd(userId=userArr['userId'], confirmMail=params['confirmMail'], siteId=siteArr['siteId'])
   return reprEx(res)

@app.route('/siteList', methods=['GET','POST'])
def returner_siteList():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token']): return reprEx({'status':False, 'code':4001, 'error':'Не передано одно из обязательных полей'})
   #ищем по токену
   siteIds=mysqlSelect('SELECT siteId  FROM buber.sysTokens WHERE token="%s" and project="returner"'%params['token'], '_buber_')
   if not siteIds: return reprEx({'status':True, 'code':200, 'data':[]})
   siteIds=[k['siteId'] for k in siteIds] if siteIds else []
   if not siteIds: return reprEx({'status':False, 'code':4002, 'error':'Токен не найден'})
   elif len(siteIds)==1 and siteIds[0]==0: return reprEx({'status':False, 'code':4003, 'error':'Не найдено сайтов'})
   elif siteIds:
      sel=mysqlSelect('SELECT siteId, siteUrl, siteName from tblsites WHERE siteId IN (%s)'%','.join(strEx(k) for k in siteIds), '_buber_')
      sel2=mysqlSelect('SELECT * from returner.sites WHERE siteId IN (%s)'%','.join(strEx(k) for k in siteIds), '_buber4_')
      returnerSitesMap={k['siteId']:k for k in sel2} if sel2 else {}
      res['data']=[]
      for row in sel:
         obj={'id':row['siteId'], 'url':row['siteUrl'], 'name':row['siteName']}
         obj['dateEnd']=returnerSitesMap[row['siteId']]['siteDateEnd'].strftime('%Y-%m-%d') if row['siteId'] in returnerSitesMap and returnerSitesMap[row['siteId']]['siteDateEnd'] else False
         res['data'].append(obj)
   res['status']=True
   return reprEx(res)

@app.route('/site', methods=['GET','POST'])
def returner_siteInfo():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token','siteId']): return reprEx({'status':False, 'code':9001, 'error':'Не передано одно из обязательных полей'})
   #ищем по токену
   sel=mysqlSelectOne('SELECT siteId FROM buber.sysTokens WHERE token="%s" and siteId="%s" and project="returner"'%(params['token'],params['siteId']), '_buber_')
   if not sel: return reprEx({'status':False, 'code':9002, 'error':'Токен не найден или нет прав на управление данным сайтом'})
   #данные сайта
   sel=mysqlSelectOne('SELECT siteId, siteUrl, siteName from tblsites WHERE siteId IN (%s)'%params['siteId'], '_buber_')
   if not sel: return reprEx({'status':False, 'code':9003, 'error':'Внутренняя ошибка или сайт не найден'})
   res['data']=sel
   sel=mysqlSelectOne('SELECT * FROM returner.sites WHERE siteId="%s"'%params['siteId'],'_buber4_')
   res['data']['confirmMail']=sel['confirmMail'] if sel else ''
   res['data']['subdomains']=True if sel and sel['subdomains']==1 else False
   #данные оплаты
   payArr=mysqlSelectOne('SELECT * FROM returner.pays WHERE siteId="%s" ORDER BY payId DESC'%(params['siteId']),'_buber4_')
   if not payArr: res['data']['subscrFee']=int(1)
   else: res['data']['subscrFee']=int(payArr['payType'])

   res['status']=True
   return reprEx(res)

getVisitsData=ReturnerApi_getVisitsData()
app.add_url_rule('/getDataForGraphs', 'getDataForGraphs', getVisitsData.do, methods=['GET','POST'])

@app.route('/getCode', methods=['GET','POST'])
def returner_getCode():
   params=getParams(request)
   if not checkParams(params, ['token']): return reprEx({'status':False, 'code':6001, 'error':'Не передано одно из обязательных полей'})
   res={'status':True, 'data':{'code':'<script type="text/javascript" src="https://returner.ru/js/stats.js" async></script>'}, 'code':200}
   return reprEx(res)

@app.route('/profile', methods=['GET','POST'])
def returner_profile():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token']): return reprEx({'status':False, 'code':9001, 'error':'Не передано одно из обязательных полей'})
   userId=getUserByToken(params['token'])
   if not userId or userId==0: return reprEx({'status':False, 'code':9002, 'error':'Токен не найден'})
   sel=mysqlSelectOne('SELECT userId, userMail, userName, userTel FROm sysUsers WHERE userId="%s"'%userId,'_buber_')
   if not sel: return reprEx({'status':False, 'code':9003, 'error':'Пользователь не найден'})
   res['data']={'mail':sel['userMail'],'name':sel['userName'],'phone':sel['userTel']}
   res['status']=True
   return reprEx(res)


@app.route('/profileEdit', methods=['GET','POST'])
def returner_profileEdit():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token']): return reprEx({'status':False, 'code':7001, 'error':'Не передано одно из обязательных полей'})
   userId=getUserByToken(params['token'])
   if not userId or userId==0: return reprEx({'status':False, 'code':7002, 'error':'Токен не найден'})
   qArr={'update':'sysUsers','where':['userId="%s"'%userId], 'set':[]}
   # if 'mail' in params and params['pass'] and params['pass']!='': qArr['set'].append({'userMail':params['mail']})
   if 'name' in params and params['name'] and params['name']!='': qArr['set'].append({'userName':params['name']})
   if 'phone' in params and params['phone'] and params['phone']!='': qArr['set'].append({'userTel':params['phone']})
   if 'pass' in params and params['pass'] and params['pass']!='': qArr['set'].append({'userPass':md5(params['pass'])})
   if not len(qArr['set']): return reprEx({'status':False, 'code':7003, 'error':'Не передано ни одно поле для обновления'})
   q=queryCreate(qArr)
   mysqlQuery(q,'_buber_')
   res['status']=True
   res['data']=params
   return reprEx(res)

@app.route('/edit', methods=['GET','POST'])
def returner_siteEdit():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token','siteId']): return reprEx({'status':False, 'code':8001, 'error':'Не передано одно из обязательных полей'})
   userArr={'token':params['token']}
   userId=getUserByToken(params['token'])
   if not userId or userId==0: return reprEx({'status':False, 'code':8002, 'error':'Токен не найден'})
   userArr['userId']=userId
   #разбираемся с правами
   sel=mysqlSelectOne('SELECT rights FROM sysTokens WHERE userId="%s" and token="%s" and siteId="%s" and project="returner"'%(userArr['userId'], userArr['token'], params['siteId']), '_buber_')
   if not sel:
      sel=mysqlSelectOne('SELECT * FROM sysRights WHERE masterUserId!="%s" AND slaveSiteId="%s" AND project="returner"'%(userArr['userId'], params['siteId']),'_buber_')
      if not sel: return reprEx({'status':False, 'code':8003, 'error':'Нет прав на редактирование данного сайта'})
   #обновляем сайт
   ok=False
   if 'siteName' in params and params['siteName'] and params['siteName']!='':
      mysqlQuery('UPDATE tblsites SET siteName="%s" WHERE siteId="%s"'%(params['siteName'],params['siteId']),'_buber_')
      ok=True
   qArr={'update':'returner.sites','where':['siteId="%s"'%params['siteId']], 'set':[]}
   if 'confirmMail' in params and params['confirmMail'] and params['confirmMail']!='': qArr['set'].append({'confirmMail':params['confirmMail']})
   print params
   if 'subdomains' in params: qArr['set'].append({'subdomains':1 if params['subdomains']=='true' else 0})
   print_r(qArr)
   if len(qArr['set']):
      q=queryCreate(qArr)
      mysqlQuery(q,'_buber4_')
      ok=True
   if not ok: return reprEx({'status':False, 'code':8004, 'error':'Не передано ни одно поле для обновления'})
   res['data']=params
   res['status']=True
   return reprEx(res)

@app.route('/stop', methods=['GET','POST'])
def returner_siteStop():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token','siteId']): return reprEx({'status':False, 'code':1101, 'error':'Не передано одно из обязательных полей'})
   userArr={'token':params['token']}
   userId=getUserByToken(params['token'])
   sel=mysqlSelectOne('SELECT * FROM sysRights WHERE masterUserId="%s" AND slaveSiteId="%s" AND project="returner"'%(userId, params['siteId']),'_buber_')
   if not sel: return reprEx({'status':False, 'code':1102, 'error':'Нет прав на остановку данного сайта'})
   q='UPDATE returner.sites SET siteActive=0 WHERE userId="%s" AND siteId="%s"'%(userId, params['siteId'])
   mysqlQuery(q, '_buber4_')
   q='UPDATE returner.pays SET recurrentActive=0 WHERE userId="%s" AND siteId="%s"'%(userId, params['siteId'])
   mysqlQuery(q, '_buber4_')
   res={'status':True, 'data':{'code':'OK'}, 'code':200}
   return reprEx(res)

@app.route('/subscrFee', methods=['GET','POST'])
def returner_subscrFee():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['token','siteId', 'fee']): return reprEx({'status':False, 'code':1201, 'error':'Не передано одно из обязательных полей'})
   if int(params['fee']) not in [1,12]: return reprEx({'status':False, 'code':1202, 'error':'Некорректный период оплаты'})
   userId=getUserByToken(params['token'])
   userArr=mysqlSelectOne('SELECT * FROM sysUsers WHERE userId="%s"'%userId,'_buber_')
   if not userArr: return reprEx({'status':False, 'code':1203, 'error':'Ошибка формирования ссылки на оплату'}) #на всякий случай
   # проверяем, есть ли уже такой счет оплаты
   payArr=mysqlSelectOne('SELECT * FROM returner.pays WHERE userId=%s AND siteId=%s'%(userId, params['siteId']),'_buber4_')
   if not payArr:
      insArr={'userId':userId, 'siteId':params['siteId'], 'payType':params['fee'],
            'paySum':7500 if int(params['fee'])==12 else 790*int(params['fee']),
            'payConfirm':0, 'payDateCreate':datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'lastDatePaid':'0000-00-00 00:00:00'}
      mysqlInsert(insArr, 'returner.pays', '_buber4_')
      payArr=mysqlSelectOne('SELECT * FROM returner.pays WHERE userId=%s AND siteId=%s'%(userId, params['siteId']),'_buber4_')
   if not payArr: return reprEx({'status':False, 'code':1203, 'error':'Ошибка формирования ссылки на оплату'}) #на всякий случай
   #теперь создаём платежный счет
   payCardArr=mysqlSelectOne('SELECT * FROM buber.sysPaysCard WHERE userId=%s AND siteId=%s'%(userId, params['siteId']),'_buber_')
   if not payCardArr:
      insArr={'userId':userId, 'siteId':params['siteId'], 'paySum':payArr['paySum'], 'confirm':0, 'equier':'rfi',
            'dateCreate':payArr['payDateCreate'], 'datePaid':'0000-00-00 00:00:00',
            'orderId':payArr['payId'], 'project':'returner', 'mail': userArr['userMail'], 'phone': userArr['userTel'],
            'payName': u'Абонентская плата за пользование сервисом Returner', 'recurrent':0}
      # print_r(insArr)
      payCardId=mysqlInsert(insArr,'sysPaysCard','_buber_')
      payCardArr=mysqlSelectOne('SELECT * FROM buber.sysPaysCard WHERE userId=%s AND siteId=%s'%(userId, params['siteId']),'_buber_')
   if not payCardArr: return reprEx({'status':False, 'code':1203, 'error':'Ошибка формирования ссылки на оплату'}) #на всякий случай
   #теперь формируем ссылку на оплату
   postData={'key':'gaG3aeNOT9+WQp8smC3ltjWEh/vwmWZaLMjJ0Y+cDTE=',
         'cost': payCardArr['paySum'],
         'name':strUniDecode(payCardArr['payName']),
         'email':payCardArr['mail'],
         'order_id':payCardArr['orderId']}
   payLink='https://partner.rficb.ru/alba/input/?%s'%urllib.urlencode(postData)
   if not payLink: return reprEx({'status':False, 'code':1203, 'error':'Ошибка формирования ссылки на оплату'})
   res['data']={'link':payLink}
   res['status']=True
   return reprEx(res)


@app.route('/remember', methods=['GET','POST'])
def returner_rememberPassword():
   params=getParams(request)
   res={'status':None, 'data':False, 'code':200}
   if not checkParams(params, ['mail']): return reprEx({'status':False, 'code':1301, 'error':'Не передано одно из обязательных полей'})

   #! костыль
   res={'status':True, 'data':{'code':'Ссылка на восстановление пароля отправлена на E-mail'}, 'code':200}
   return reprEx(res)

if __name__ == '__main__':
   isTestMode=False
   if '_test' in sys.argv[0]: isTestMode=True
   if len(sys.argv)>1 and 'test'==sys.argv[1]: isTestMode=True
   _sql.threadSafety=2
   _sql.pool('_buber_', size=20)  # for fast-checking tokens
   # _sql.pool('_buber4_', size=100)
   _sql.alias['_217.174.106.16_']='_buber_'
   _sql.alias['_217.174.106.18_']='_buber2_'
   _sql.alias['_144.76.43.233_']='_buber3_'
   _sql.alias['_144.76.72.221_']='_buber4_'
   _sql.alias['_144.76.72.213_']='_buber4_'
   _sql.alias['_yobsta_']='_buber4_'
   _sql.alwaysUsePool+=['_buber_']
   t=threading.Thread(target=ReturnerApiWithCache_contacts.cicle)
   t.daemon=True
   t.start()
   app.run(host='s4.buber.ru', port=1489 if isTestMode else 1488, debug=False, threaded=True)
