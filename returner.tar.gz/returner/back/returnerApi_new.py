# -*- coding: utf-8 -*-

from functionsex import *
from sqlWrap import _sql

regExp_buberToken=re.compile(r'^[0-9a-f]+$')

from flask import request

#************************* this must be moved to utils.py

def getParams(request):
   params={}
   if request.method == 'POST':
      params={k:v for k,v in request.form.iteritems()}
   else:
      # print request.args
      for k in request.args:
         params[k]=request.args.get(k)
   params={k:cleanInData(v,k) for k,v in params.iteritems()}
   #!сделать проверку, чтобы siteId было только из цифр
   return params

def cleanInData(s, col=False):
   if not s: return s
   if col in ('url','siteName'): replaceArr=('\\','%','!','"',"'")
   else: replaceArr=('\\','//','%','!','"',"'")
   s=s.strip()
   for r in replaceArr:
      s=s.replace(r,'')
   # s=s.replace("'",'').replace("\\",'').replace("//",'').replace("%",'').replace("!",'').replace('"','')
   return s

def checkParams(params, keys):
   #!сделать проверку на кавычки и на то, что siteId всегда должен быть числом
   for k in keys:
      if k not in params or params[k]=='': return False
   return True

#*************************


class ReturnerApiError(Exception):
   def __init__(self, code, msg):
      super(ReturnerApiError, self).__init__(msg)
      self.code=code
      self.msg=msg

   def __str__(self):
      return 'ReturnerApiError(%s): %s'%(self.code, self.msg)

class ReturnerApiWithCache_contacts(object):
   contacts={
      'map':set(),
      'lastCheck':0,
      'maxId':0,
      'updating':False,
      'intervalMax':5*60,
      'intervalMin':10,
      'chunk':1000,
      'needStopCicle':False,
   }

   def __init__(self):
      self.updateCache()

   @classmethod
   def cicle(cls):
      tMax=cls.contacts['intervalMax']
      tMin=cls.contacts['intervalMin']
      t=tMax
      while not cls.contacts['needStopCicle']:
         r=cls.updateCache()
         if r is True:  # just loaded new data
            t=tMax
         elif r is False:  # checked but no new data
            t=max(t/2.0, tMin)
         elif r is None:  # no reasons for checking
            #? это поведение оставлено на будущее, сейчас такой статус может вернуться, только если ктото другой уже обновляет кеш
            t=tMax
         time.sleep(t)

   @classmethod
   def updateCache(cls):
      o=cls.contacts
      if o['updating']: return
      o['updating']=True
      try:
         q='SELECT max(visitorId) as maxId from returner.visitorsContacts'
         maxId=_sql.query(q, '_buber4_', selectMode='one', silentError=False)['maxId']
         if maxId<=o['maxId']:
            o['lastCheck']=time.time()
            o['updating']=False
            return False
         mytime=time.time()
         c=0
         i=o['maxId']
         stepI=o['chunk']
         while True:
            if(i>=maxId+1): break
            oldI=i
            i+=(stepI if maxId-i>=stepI else maxId-i)
            if oldI==i: break
            q='SELECT siteId, userSha from returner.visitorsContacts where visitorId>%s and visitorId<=%s'%(oldI, i)
            tArr1=_sql.query(q, '_buber4_', selectMode='all', silentError=False)
            for oo in tArr1:
               c+=1
               o['map'].add('%(siteId)s#%(userSha)s'%oo)
         o['maxId']=maxId
         o['lastCheck']=time.time()
         print 'Contacts data loaded (%s items) at'%c, time2human(time.time()-mytime, inMS=False)
      finally:
         o['updating']=False
      return True

class ReturnerApi_getVisitsData(ReturnerApiWithCache_contacts):

   def __init__(self):
      super(ReturnerApi_getVisitsData, self).__init__()
      self.__methodsQueue=[
         self._prepareEnv,
         self.__visitsFromCache,
         self._loadUsersByDate,
         self._loadDataForUsers,
         self._prepareResult,
         self.__visitsToCache,
      ]

   def __call__(self, *args, **kwargs):
      return self.do(*args, **kwargs)

   def _fillDateInterval(self, dateFrom, dateTo):
      step=datetime.timedelta(days=1)
      s=dateFrom
      while s<=dateTo:
         yield s.strftime('%Y-%m-%d')
         s+=step

   def do(self, returnRaw=False):
      mytime0=time.time()
      speed={'byMethod':{}}
      params=MagicDict(getParams(request))
      tmp=MagicDict()
      for m in self.__methodsQueue:
         mytime=time.time()
         try:
            m(speed, params, tmp)
            speed['byMethod'][m.__name__]=time2human(time.time()-mytime, inMS=False)
         except ReturnerApiError, e:
            speed['byMethod'][m.__name__]=time2human(time.time()-mytime, inMS=False)
            tmp.result={'status':False, 'code':e.code, 'error':e.msg}
            break
         except Exception:
            speed['byMethod'][m.__name__]=time2human(time.time()-mytime, inMS=False)
            tmp.result={'status':False, 'code':500, 'error':getErrorInfo()}
            print tmp.result['error']
            break
      speed['FULL']=time2human(time.time()-mytime0, inMS=False)
      tmp.result['speed']=speed
      return tmp.result if returnRaw else reprEx(tmp.result)

   def _checkToken(self, speed, params, tmp):
      if not params.token or not isStr(params.token) or not regExp_buberToken.match(params.token):
         raise ReturnerApiError(3002, 'Токен не найден')
      q='SELECT userId FROM buber.sysTokens WHERE token="%s" and siteId="%s" and project="returner"'%(params.token, params.siteId)
      tmp.userId=_sql.query(q, '_buber_', selectMode='str', silentError=False)
      if not tmp.userId:
         raise ReturnerApiError(3002, 'Токен не найден')

   def _prepareEnv(self, speed, params, tmp):
      mytime=time.time()
      if not checkParams(params, ('token', 'siteId')):
         raise ReturnerApiError(5001, 'Не передано одно из обязательных полей')
      self._checkToken(speed, params, tmp)
      speed['check token']=time2human(time.time()-mytime, inMS=False)
      mytime=time.time()
      tmp.dateFromStr=params.get('dateFrom') or (datetime.datetime.now()-datetime.timedelta(days=7)).strftime('%Y-%m-%d')
      tmp.dateFrom=datetime.datetime.strptime(tmp.dateFromStr, "%Y-%m-%d").date()
      tmp.dateFromMK=int(time.mktime(tmp.dateFrom.timetuple()))
      tmp.dateToStr=params.get('dateTo') or datetime.datetime.now().strftime('%Y-%m-%d')
      tmp.dateTo=datetime.datetime.strptime(tmp.dateToStr, "%Y-%m-%d").date()
      tmp.dateToMK=int(time.mktime(tmp.dateTo.timetuple()))
      tmp.loadDates=list(self._fillDateInterval(tmp.dateFrom, tmp.dateTo))
      tmp.map_user2date=defaultdict(list)
      tmp.loadUsers=defaultdict(list)
      tmp.result={}
      speed['prepare env']=time2human(time.time()-mytime, inMS=False)

   def __visitsFromCache(self, speed, params, tmp):
      mytime=time.time()
      tmp.data_visits={}
      tmp._usersByDateFromCache=defaultdict(list)
      s=','.join("\'%s#%s\'"%(params.siteId, s) for s in tmp.loadDates)
      q='SELECT date,data FROM returner.cache_visitsByDate WHERE id IN (%s)'%s
      sel=_sql.query(q, '_buber4_', selectMode='all', silentError=False) or ()
      speed['searching data in remote cache']=time2human(time.time()-mytime, inMS=False)
      mytime=time.time()
      mytime_json=0
      for o in sel:
         tmp.loadDates.remove(o['date'])
         date=datetime.datetime.strptime(o['date'], "%Y-%m-%d").date()
         if isStr(o['data']):
            mytime1=time.time()
            o['data']=ujson.loads(o['data'])
            mytime_json+=time.time()-mytime1
         for oo in o['data']:
            u=oo['userSha']
            if u not in tmp.data_visits or date>tmp.data_visits[u]['date']:
               oo['date']=date
               tmp.data_visits[u]=oo  # изза того, что `visitsSessions` постоянно перезаписывается, здесь должна быть самая поздняя версия данных
            tmp._usersByDateFromCache[date].append(u)
      speed['preparing data from cache']=time2human(time.time()-mytime, inMS=False)
      speed['parsing json from cache']=time2human(mytime_json, inMS=False)

   def _loadUsersByDate(self, speed, params, tmp):
      if tmp.loadDates:
         mytime=time.time()
         s=','.join("\'%s\'"%s for s in tmp.loadDates)
         speed['dates not in cache']=tmp.loadDates
         q='SELECT userSha, date FROM returner.visitsByDate where siteId=%s and date IN (%s)'%(params.siteId, s)
         sel=_sql.query(q, '_buber4_', selectMode='all', silentError=False) or ()
         speed['search userSha by date']=time2human(time.time()-mytime, inMS=False)
         mytime=time.time()
         for o in sel:
            tmp.loadUsers[o['date'].strftime('%Y-%m-%d')].append(o['userSha'])
            tmp._usersByDateFromCache[o['date']].append(o['userSha'])
         speed['preparing non-cache map']=time2human(time.time()-mytime, inMS=False)
      mytime=time.time()
      tArr=tmp._usersByDateFromCache.keys()
      tArr.sort()
      for date in tArr:
         for u in tmp._usersByDateFromCache[date]:
            tmp.map_user2date[u].append(date)
      speed['processing userSha by date']=time2human(time.time()-mytime, inMS=False)
      tmp._usersByDateFromCache=None

   def _loadDataForUsers_cbNonCache_visits(self, sel, q, date=None, speed=None, params=None, tmp=None):
      mytime=time.time()
      _date=datetime.datetime.strptime(date, "%Y-%m-%d").date()
      # badDate=(datetime.datetime.now()-datetime.timedelta(days=1)).date()  #! не кешируем не только сегодняшний день, но и вчеравшний - чтобы избежать проблем с "переходым" часом в случае инконсистентности часовых поясов сервера и клиента. но нужно убедиться, что это нужно делать
      badDate=datetime.datetime.now().date()
      sel=sel or ()
      for o in sel:
         u=o['userSha']
         if _date<badDate:
            tmp.toCache_visits[date].append(o)
         if u not in tmp.data_visits or _date>tmp.data_visits[u]['date']:
            o=o.copy()
            o['date']=_date
            tmp.data_visits[u]=o  # изза того, что `visitsSessions` постоянно перезаписывается, здесь должна быть самая поздняя версия данных
      tmp._mytime_cbNonCache_visits+=time.time()-mytime
      tmp._jobs-=1

   def _loadDataForUsers_cb_visits(self, speed=None, params=None, tmp=None):
      c, mytime0=0, time.time()
      for u, o in tmp.data_visits.iteritems():
         c+=1
         if c>10000 and time.time()-mytime0>=0.5:
            time.sleep(0.00001)
            c, mytime0=0, time.time()
         mytime=time.time()
         dates=tmp.map_user2date[u]
         _withContacts=params.siteId+'#'+u in self.contacts['map']
         _isReturn=False
         #
         if _withContacts:
            tmp.count_contacts+=1
         tmp._mytime_cb_visits0+=time.time()-mytime
         # part from siteCntVisits
         mytime=time.time()
         if o['firstVisit']<tmp.dateFromMK: _isReturn=True   #? както странно, а где гарантия что он встретится и в промежутке дат тоже
         elif len(dates)==1: tmp.count_new+=1
         else:
            c=0
            for date in dates:
               if date<tmp.dateFrom:  #был заход раньше, чем начало диапозона
                  # c=2  #? както странно, а где гарантия что он встретится и в промежутке дат тоже
                  # break
                  c+=1  #? FIXED: смотри выше
               elif date>tmp.dateTo: break  #? FIXED: насколько я понимаю, эту штука здесь нужна (а поскольку данные всегда отсортированы, нет смысла обрабатывать дальше)
               elif date>=tmp.dateFrom and date<=tmp.dateTo: c+=1  #? FIXED: было date+=c но это бессмыслица
               if c>=2: break  #? FIXED: добавил условие выхода, какой смысл молотить дальше
            if c>=2:
               _isReturn=True
            else:
               tmp.count_new+=1
         if _isReturn:
            tmp.count_return+=1
            if _withContacts:
               tmp.count_returnContacts+=1
         if _withContacts:
            for date in dates:
               date=date.strftime('%Y-%m-%d')
               tmp.count_byDate[date]['contacts']+=1
               if _isReturn:
                  tmp.count_byDate[date]['returnContacts']+=1
         tmp._mytime_cb_visits1+=time.time()-mytime
         # part from sitePeriodVisits
         mytime=time.time()
         if isStr(o['visitsSessions']):
            o['visitsSessions']=ujson.loads(o['visitsSessions'])
            if len(o['visitsSessions'])>1:
               o['visitsSessions'].sort()
         vs=o['visitsSessions']
         if len(vs)==1: continue
         for i in xrange(len(vs)):
            if i==0: continue
            if vs[i]<tmp.dateFromMK: continue
            if vs[i]>tmp.dateToMK: break  #? FIXED: насколько я понимаю, эту штука здесь нужна (а поскольку данные всегда отсортированы, нет смысла обрабатывать дальше)
            d1=datetime.datetime.fromtimestamp(vs[i])
            d2=datetime.datetime.fromtimestamp(vs[i-1])
            days=(d1-d2).days
            if days==0: continue
            elif days==1: tmp.visitsByPeriod['1']+=1
            elif days==2: tmp.visitsByPeriod['2']+=1
            elif days==3: tmp.visitsByPeriod['3']+=1
            elif days<=7: tmp.visitsByPeriod['4-7']+=1
            elif days<=14: tmp.visitsByPeriod['8-14']+=1
            elif days<=30: tmp.visitsByPeriod['15-30']+=1
            elif days<=60: tmp.visitsByPeriod['31-60']+=1
            elif days<=120: tmp.visitsByPeriod['61-120']+=1
         tmp._mytime_cb_visits2+=time.time()-mytime
      tmp._jobs-=1

   def _loadDataForUsers(self, speed, params, tmp):
      mytime=time.time()
      tmp.count_byDate={k:{'contacts':0,'returnContacts':0} for k in self._fillDateInterval(tmp.dateFrom, tmp.dateTo)}
      tmp.count_return=0
      tmp.count_contacts=0
      tmp.count_returnContacts=0
      tmp.count_new=0  #! не используется
      tmp.visitsByPeriod={'1':0, '2':0, '3':0, '4-7':0,'8-14':0,'15-30':0,'31-60':0,'61-120':0}
      tmp._mytime_cbNonCache_visits=0
      tmp._mytime_cb_visits0=0
      tmp._mytime_cb_visits1=0
      tmp._mytime_cb_visits2=0
      tmp.toCache_visits=defaultdict(list)
      speed['prepare counters']=time2human(time.time()-mytime, inMS=False)
      # load not-cached visits
      mytime=time.time()
      tmp._jobs=0
      c1=0
      for date, users in tmp.loadUsers.iteritems():
         if not users: continue
         c1+=len(users)
         ids=','.join("\'%s\'"%s for s in users)
         q='SELECT userSha, firstVisit, visitsSessions FROM returner.visits WHERE siteId=%s AND userSha IN (%s)'%(params.siteId, ids)
         f=bind(self._loadDataForUsers_cbNonCache_visits, {'date':date, 'speed':speed, 'params':params, 'tmp':tmp})
         tmp._jobs+=1
         _sql.query(q, '_buber4_', async=True, cb=f, selectMode='all', silentError=False)
      speed['jobs-watcher-points']=[]
      while tmp._jobs:
         time.sleep(0.5)
         if not tmp._jobs: break
         speed['jobs-watcher-points'].append(tmp._jobs)
      #
      speed['load non-cached visits(%s)'%c1]=time2human(time.time()-mytime, inMS=False)
      speed['cbNonCache_visits']=time2human(tmp._mytime_cbNonCache_visits, inMS=False)
      mytime=time.time()
      self._loadDataForUsers_cb_visits(speed, params, tmp)
      speed['cb_visitsFull']=time2human(time.time()-mytime, inMS=False)
      speed['cb_visits0']=time2human(tmp._mytime_cb_visits0, inMS=False)
      speed['cb_visits1']=time2human(tmp._mytime_cb_visits1, inMS=False)
      speed['cb_visits2']=time2human(tmp._mytime_cb_visits2, inMS=False)

   def __visitsToCache(self, speed, params, tmp):
      mytime=time.time()
      qArr=[]
      for date, data in tmp.toCache_visits.iteritems():
         if not data: continue
         q={
            'id':'%s#%s'%(params.siteId, date),
            'date':date, 'siteId':params.siteId,
            'userSha':'|%s|'%('|'.join(o['userSha'] for o in data)),
            'dataKeys':'userSha,firstVisit,visitsSessions',
            'data':prepDataMYSQL(ujson.dumps(data)),
            'count':len(data),
         }
         qArr.append(_sql.insert(q, 'returner.cache_visitsByDate', returnQuery=True))
      speed['preparing data for cache']=time2human(time.time()-mytime, inMS=False)
      if qArr:
         mytime=time.time()
         _sql.query(';'.join(qArr), '_buber4_', async=True, silentError=False, asyncWait=False)
         speed['async insert data to cache']=time2human(time.time()-mytime, inMS=False)

   def _prepareResult(self, speed, params, tmp):
      tmp.result={'status':True, 'code':200, 'data':{'siteCntVisits':None,'sitePeriodVisits':None}}
      # creating results for siteCntVisits
      mytime=time.time()
      tmp.result['data']['siteCntVisits']={'status':True, 'data':{}, 'code':200}
      data=tmp.result['data']['siteCntVisits']['data']
      data['summary']={}
      data['summary']['visits']=len(tmp.map_user2date)  #? FIXED: сейчас здесь колво уникальных посетителей за период, а раньше было с учетом повторов
      data['summary']['new']=tmp.count_new  #! не используется
      data['summary']['contacts']=tmp.count_contacts
      data['summary']['returns']=tmp.count_return
      data['summary']['returnContacts']=tmp.count_returnContacts
      data['detail']=tmp.count_byDate
      speed['formatting results for siteCntVisits']=time2human(time.time()-mytime, inMS=False)
      # creating results for sitePeriodVisits
      mytime=time.time()
      tmp.result['data']['sitePeriodVisits']={'status':True, 'data':{'columns':[],'values':[]}, 'code':200}
      data=tmp.result['data']['sitePeriodVisits']['data']
      columnsSort=['1', '2', '3', '4-7','8-14','15-30','31-60','61-120']
      for k in columnsSort:
         if tmp.visitsByPeriod[k]==0: continue
         if k=='1':
            data['columns'].append('%s день'%k)
         elif k=='2' or k=='3':
            data['columns'].append('%s дня'%k)
         else:
            data['columns'].append('%s дней'%k)
         data['values'].append(tmp.visitsByPeriod[k])
      speed['formatting results for sitePeriodVisits']=time2human(time.time()-mytime, inMS=False)
