# -*- coding: utf-8 -*-
import sys, re, os, random, math, imp, threading, gc, datetime
sys.path.append('/home/python/libs/')
sys.path.append('/home/python/')
sys.path.append('/home/python/cycles/')
sys.path.append('/home/python/apiFuncs')
sys.path.append('/home/python/api/')
from functionsex import *
from globals import *
from func import *
from sqlWrap import _sql

_sitePagesHash={'sitesMap':{},
				'pagesMap':{}}

def returnerMailReg(userId=False):
	tpl="reg"
	userArr=mysqlSelectOne('SELECT userMail, userName FROM sysUsers WHERE userId="%s"'%userId,'_buber_')
	#готовим данные
	html=fileGet('/home/python/returner/mailTpl/%s.html'%tpl).decode('utf-8')
	params={'login':userArr['userMail']}
	for k,v in params.items(): html=html.replace('{%s}'%k,v)
	# создаем письмо
	insArr={'email':userArr['userMail'].decode('utf-8'),
			'type':tpl.decode('utf-8'),
			'subject':'Регистрация в сервисе Returner'.decode('utf-8'),
			'body':prepDataMYSQL(html),
			'params':prepDataMYSQL({'userId':userId})
			}
	print mysqlInsert(insArr,'returner.mails','_buber4_', debug=True)

def returnerSiteAdd(userId=False, confirmMail=False, siteId=False):
	tpl="confirm"
	#готовим данные
	# userArr=mysqlSelectOne('SELECT userMail, userName FROM sysUsers WHERE userId="%s"'%userId,'_buber_')
	siteArr=mysqlSelectOne('SELECT siteId, siteUrl, siteName FROM tblsites WHERE siteId="%s"'%siteId, '_buber_')
	html=fileGet('/home/python/returner/mailTpl/%s.html'%tpl).decode('utf-8')
	params={'siteName':siteArr['siteName'], 'siteUrl':siteArr['siteUrl'], 'confirmLink':'https://returner.ru/lk/'}
	for k,v in params.items(): 
		# print k
		# print v
		html=html.replace('{%s}'%k,v)
	# создаем письмо
	insArr={'email':confirmMail.decode('utf-8'),
			'type':tpl.decode('utf-8'),
			'subject':'Подтверждение e-mail в сервисе Returner'.decode('utf-8'),
			'body':prepDataMYSQL(html),
			'params':prepDataMYSQL({'userId':userId, 'confirmMail':confirmMail, 'siteId':siteId})
			}
	print mysqlInsert(insArr,'returner.mails','_buber4_', debug=True)

def returnerReturn(siteArr=False, userSha=False, visit=False, visitorContacts=False,ref=False, href=False):
	global _sitePagesHash
	if siteArr['siteActive']!=1: return  #сайт не оплачен
	tpl="return"
	#шаблон таблицы
	rowTpl='<tr style="padding: 20px 20px 20px 60px; font-family:&#x27;Rubik&#x27;, sans-serif; font-size: 15px;background: linear-gradient(to bottom, #F5F5F5, #FFF); ">\
            	<td class="left-td" style="border-left: 2px solid #39b54a;min-width: 240px; padding:16px 13px 15px 48px; text-align: left;">{key}</td>\
            	<td  class="right-td" style="min-width: 100px;padding:16px 43px 15px 18px; text-align: left;">{value}</td>\
            </tr>'
	params={'contactsTable':'', 'ref':'', 'utmTable':'', 'pagesTable':'','sessionsTable':''}
	#контакты
	for k,v in visitorContacts.items(): visitorContacts[k]=v if isString(v) else strEx(v)
	if visitorContacts and visitorContacts['userName']: params['contactsTable']+=rowTpl.replace('{key}','Имя'.decode('utf-8')).replace('{value}',visitorContacts['userName'])
	if visitorContacts and visitorContacts['userPhone']: params['contactsTable']+=rowTpl.replace('{key}','Телефон'.decode('utf-8')).replace('{value}',visitorContacts['userPhone'])
	if visitorContacts and visitorContacts['userMail']: params['contactsTable']+=rowTpl.replace('{key}','E-mail'.decode('utf-8')).replace('{value}',visitorContacts['userMail'])
	#====источник====
	params['ref']='<a href = "{ref}" target="_blank"> {ref} </a>'.replace('{ref}',ref) if ref else 'Прямой заход'.decode('utf-8')
	# #====utm====
	utm, utmArr=urlUtmSplit(href)
	if utmArr:
		for key, value in utmArr.items(): 
			params['utmTable']+=rowTpl.replace('{key}',key).replace('{value}',value)
	# #====просмотренные страницы====
	visitsData=visit['visitsData']
	if visitsData and isString(visitsData):
		visitsData={'sessions':[], 'mktime':[], 'pageIds':[]} if strEx(visitsData)==strEx("None") else json.loads(visitsData)
	if not len(visitsData['sessions']):
		print '!!!нет сессий в visitData'
		return False
	sessionId=visitsData['sessions'][-1] #берем последнюю сессию
	pageIds={visitsData['pageIds'][i]:visitsData['mktime'][i] for i in xrange(len(visitsData['sessions'])) if visitsData['sessions'][i]==sessionId}
	#данные хранилища страниц сайта====
	if siteArr['siteId'] not in _sitePagesHash['sitesMap']:
		# print 'сайта нет в _sitePagesHash["sitesMap"], достаём'
		q='SELECT siteId, server, dbPostfix FROM tblsites WHERE siteId=%s'%siteArr['siteId']
		siteDbArr=mysqlSelectOne(q,'_buber_')
		_sitePagesHash['sitesMap'][siteArr['siteId']]=siteDbArr
		_sitePagesHash['pagesMap'][siteArr['siteId']]={}
	else: siteDbArr=_sitePagesHash['sitesMap'][siteArr['siteId']]
	#достаём страницы
	needPages=[strEx(k) for k in pageIds.keys() if k not in _sitePagesHash['pagesMap'][siteArr['siteId']]]
	pagesArr=mysqlSelect('SELECT pageId, pageUrl FROM siteParser%s.sitePages WHERE siteId=%s AND pageId IN (%s)'%(siteDbArr['dbPostfix'], siteArr['siteId'], ','.join(needPages)), '_%s_'%(siteDbArr['server']))
	if pagesArr:
		 for k in pagesArr:
			_sitePagesHash['pagesMap'][siteArr['siteId']][k['pageId']]=urllib.unquote(k['pageUrl'])
	for pageId, mktime in pageIds.items():
		if pageId not in _sitePagesHash['pagesMap'][siteArr['siteId']]:
			print 'нет такой страницы'
			continue
		try: pageUrl=_sitePagesHash['pagesMap'][siteArr['siteId']][pageId].decode('utf-8')
		except: pageUrl=_sitePagesHash['pagesMap'][siteArr['siteId']][pageId]
		visitTime=datetime.datetime.fromtimestamp(int(mktime)+7200).strftime('%Y-%m-%d %H:%M:%S') #добавляем 2 часа, для МСК #!нужно добавить гео смещение
		params['pagesTable']+=rowTpl.replace('{key}','<a href="%s" target="_blank">%s</a>'%(pageUrl,pageUrl)).replace('{value}',visitTime) 
	# #====предыдущие визиты
	lastSessionId=visitsData['sessions'][-1]
	previousSessions={}
	for i in xrange(len(visitsData['sessions'])):
		if visitsData['sessions'][i]==lastSessionId: break
		if visitsData['sessions'][i] not in previousSessions:
			previousSessions[visitsData['sessions'][i]]={'mktime':visitsData['mktime'][i],'countPages':0}
		previousSessions[visitsData['sessions'][i]]['countPages']+=1
	# print_rd(previousSessions)
	for k in previousSessions.values():
		visitTime=datetime.datetime.fromtimestamp(int(k['mktime'])+7200).strftime('%Y-%m-%d') #добавляем 2 часа, для МСК #!нужно добавить гео смещение
		countPages=strEx(k['countPages'])
		params['sessionsTable']+=rowTpl.replace('{key}',visitTime).replace('{value}',countPages)
	#создаём письмо
	html=fileGet('/home/python/returner/mailTpl/%s.html'%tpl).decode('utf-8')
	for k,v in params.items(): html=html.replace('{%s}'%k,v)
	# создаем письмо
	insArr={'email':siteArr['confirmMail'].decode('utf-8'),
			'type':tpl.decode('utf-8'),
			'subject':'Новый вернувшийся покупатель - Returner'.decode('utf-8'),
			'body':prepDataMYSQL(html),
			'params':prepDataMYSQL({'siteArr':siteArr, 'userSha':userSha, 'visit':visit, 'visitorContacts':visitorContacts,'ref':ref, "href":href}).decode('utf-8')
			}
	mysqlInsert(insArr,'returner.mails','_buber4_', debug=True)
	
	pass


#проверяем статус писем
# https://api.unisender.com/ru/api/checkEmail?format=json&api_key=68ku1ah38t53qumsh5jddzbn7jqh55cuok3xn1qo&email_id=12946595041
	

# returnerMailReg(userId=1)
# returnerSiteAdd(userId=1, confirmMail='mail@ajon.ru', siteId=46223)
# print getms()
# sys.exit(0)

if __name__ == '__main__':
	# while True:
	# 	unisenderWrap()
	# 	print datetime.datetime.now()
	# 	time.sleep(15)
	siteArr={'confirmMailValidate': 0, 'siteDateAdd': datetime.datetime(2017, 12, 3, 9, 11, 19), 'userId': 3030, 'subdomains': 1, 'siteId': 9574, 'confirmMail': 'mail@ajon.ru', 'siteActive': 1, 'siteDateEnd': None}
	userSha='b8fef6aade17e13483530d50cc43e4264e212a68'
	visit= {
		  "siteId":"9574",
		  "userSha":"b8fef6aade17e13483530d50cc43e4264e212a68",
		  "visitsData":"{\"mktime\":[1514125979,1514135247],\"pageIds\":[77922833,77922833],\"sessions\":[\"421002795\",\"421002791\"]}",
		  "visitsSessions":"[1514125979,1514135247]"
		}
	visitorContacts={'userName': 'Евгений Мирой', 'visitorId': 236, 'mkFirstVisit': 1513957303809, 'userMail': 'mail@ajon.ru', 'userPhone': '+79039687380', 'siteId': 9574, 'formsData': '[{"formName":"userMail","formId":"userMail","formValue":"mail@ajon.ru ","mktime":1513957302808}]', 'userSha': 'b8fef6aade17e13483530d50cc43e4264e212a68'}
	ref=''
	href='http://ajon.ru/?utm_source=yandex'
	returnerReturn(siteArr=siteArr, userSha=userSha, visit=visit, visitorContacts=visitorContacts, ref=ref, href=href)
	pass