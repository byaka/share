//счетчикIwindow._buber=window._buber || {};
window._buber=window._buber || {};
window.buberStats=window.buberStats|| new String('buberStats');
buberStats.version=1.41;
buberStats.inited=(buberStats.inited===undefined? false: buberStats.inited);
buberStats.completed=(buberStats.completed===undefined? false: buberStats.completed);
buberStats.userSha=(buberStats.userSha===undefined? false: buberStats.userSha);
buberStats.initQueue=(buberStats.initQueue===undefined? []: buberStats.initQueue);
buberStats.isSSL=((window.top.location.protocol|| window.self.location.protocol)==='https:'? true: false);
buberStats.url=window.top.location.href|| window.self.location.href;
//настройки передаваемые извне
buberStats.processForms=(_buber.processForm===undefined? true: _buber.processForm);
buberStats.processClicks=(_buber.processClicks===undefined? false: _buber.processClicks);
buberStats.crossSubDomains=(_buber.crossSubDomains===undefined? true: _buber.crossSubDomains);
buberStats.disabled=(buberStats.disabled===undefined? false: buberStats.disabled);
buberStats.formsArr={};
buberStats.debug=(buberStats.url.indexOf('debug', 0)>=0);
buberStats.serverAdress={
   'getUserSha_old': {
      0: 'http://buber.ru/getUserSha.php',
      1: 'https://buber.ru/getUserSha.php'
   },
   'getUserSha_new': {
      0: 'http://stats.buber.ru:8099/getUserSha',
      1: 'https://stats.buber.ru:8199/getUserSha'
   },
   'statsApi': {
      0: 'http://stats.buber.ru:8099/statsApi',
      1: 'https://stats.buber.ru:8199/statsApi'
   }
};
buberStats.serverAdressDebug={  //используется, если хеш адреса содержит useDebugApi=1
   'getUserSha_old': {
      0: 'http://buber.ru/getUserSha.php',
      1: 'https://buber.ru/getUserSha.php'
   },
   'getUserSha_new': {
      0: 'http://stats.buber.ru:2099/getUserSha',
      1: 'https://stats.buber.ru:2199/getUserSha'
   },
   'statsApi': {
      0: 'http://stats.buber.ru:2099/statsApi',
      1: 'https://stats.buber.ru:2199/statsApi'
   }
};
window.functionsEx=window.functionsEx|| new String('fex');
functionsEx['scope']=null;
functionsEx['import']=false;

var buberTesting=(window.location.hash+window.location.search).replace(/[?#]/g, '&').split('&');
for(var i=0,l=buberTesting.length;i<l;i++){
   var s=buberTesting[i];
   s=s.split('=')[0];
   if(s.toLowerCase()==='abtesting'){
      buberTesting=true;
      break;
   }
}
if(buberTesting!==true) buberTesting=false;
else{
   buberStats.serverAdress.statsApi[0]='http://stats.buber.ru:6099/statsApi';
}

buberStats.getXPath=function(a){
   buberStats.stopwatch.mark({name:'getXPath', wait:false, inMS:true});
   for(var d=document.getElementsByTagName("*"),b=[];a&&1==a.nodeType;a=a.parentNode)if(a.hasAttribute("id")){for(var e=0,c=0;c<d.length&&!(d[c].hasAttribute("id")&&d[c].id==a.id&&e++,1<e);c++);if(1==e){
      b.unshift('id("'+a.getAttribute("id")+'")');
      b=b.join("/");
      buberStats.stopwatch.mark({name:'getXPath', wait:true, inMS:true});
      return b;
   }
   b.unshift(a.localName.toLowerCase()+'[@id="'+a.getAttribute("id")+'"]')}else if(a.hasAttribute("class"))b.unshift(a.localName.toLowerCase()+'[@class="'+a.getAttribute("class")+'"]');else{i=1;for(sib=a.previousSibling;sib;sib=sib.previousSibling)sib.localName==a.localName&&i++;b.unshift(a.localName.toLowerCase()+"["+i+"]")}
   b=b.length? "/"+b.join("/"): null;
   buberStats.stopwatch.mark({name:'getXPath', wait:true, inMS:true});
   return b;
};

buberStats.getCSSPath=function(a){
   buberStats.stopwatch.mark({name:'getCSSPath', wait:false, inMS:true});
   for(var e="",f=[],b,c,d;a;){b=a.nodeName.toLowerCase();c=a.id?"#"+a.id:!1;d=a.className?"."+a.className.replace(/\s+/g,"."):"";b=c?b+c+d:d?b+d:b;f.unshift(b);if(c)break;a=a.parentNode!==document?a.parentNode:!1}for(a=0;a<f.length;a++)e+=" "+f[a];
   e=e.replace(/^[ \t]+|[ \t]+$/, "");
   buberStats.stopwatch.mark({name:'getCSSPath', wait:true, inMS:true});
   return e;
};

buberStats.getCookie=function(name) {
  var matches = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)" ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
/*============================================================*/
buberStats.isIframe=function(){
   try{
      return window.self!=window.top || window.top.location!=window.self.location;
    }catch(e){
      return true;
   }
}

buberStats.domReady=function(cb){
   //вызовет cb() когда дом-дерево будет подгружено, даже если в фоне грузятся левые ресурсы типа скриптов вконтакта или картинок
   var s=document.readyState;
   if(s=='interactive' || s=='loaded' || s=='complete') return cb();
   var __timerIdForDOMReady=setInterval(function(){
      var s=document.readyState;
      if(!(s=='interactive' || s=='loaded' || s=='complete')) return;
      clearInterval(__timerIdForDOMReady);
      cb();
   }, 100)
}

buberStats.getUserSha=function(data, uid, isLoadOverJSONP){
   if(buberStats.userSha) return false;
   // console.log('>>> getuserSha', uid, isLoadOverJSONP);
   //функция трансфера данных на сервер
   var buberF = document.getElementById('buberForm');
   if(buberF) buberF.remove();
   buberF=null;
   if(!buberF){
      var _buberDiv = document.createElement('div');
      _buberDiv.id='_buberDiv';
      document.body.appendChild(_buberDiv);
      _buberDiv.innerHTML='<iframe src="" id="buberIframe" name="buberIframe" style="width:1px; height:1px; display:none;"></iframe><form method="POST" id="buberForm" target="buberIframe" action=""></form>';
      var buberF=document.getElementById('buberForm');
      var buberIframe=document.getElementById('buberIframe');
      if(isLoadOverJSONP){
         //подписываемся на событие onload айфрейма. Когда срабатывает, загружаем тотже buberWatch еще раз но уже методом JSONP
         window.buberIFrame_onload=function(){
            // console.log('++++ Submited', uid);
            window.buberWatchCB=function(data){
              // console.log('++++ JSONP', uid, data);
               _buber['__buberWatch']=data;
               if(window.buberCall)
                  buberCall['userSha']=_buber['__buberWatch']; //передаём в buberCall
               document.cookie="__buberWatch="+_buber['__buberWatch']+"; path=/; expires=2147483647;";
               buberStats.userSha=true;
            }
            // console.log('---- JSONP', uid);
            buberStats.loadJs(buberStats.serverAdress.getUserSha_new[Number(buberStats.isSSL)]+'?jsonp=buberWatchCB&uid='+uid);
         }
         if (buberIframe.attachEvent) buberIframe.attachEvent('onload', window.buberIFrame_onload);
         else buberIframe.addEventListener('load', window.buberIFrame_onload, false);
      }
   }
   var url=buberStats.serverAdress.getUserSha_new[Number(buberStats.isSSL)]+'?uid='+uid+'&'+data;
   // var url=buberStats.serverAdress.getUserSha_old[Number(buberStats.isSSL)]+'?'+data;
   buberF.setAttribute('action', url);
   // console.log('---- Submiting', uid);
   buberF.submit();
}

buberStats.loadJs=function(url, cb){
   // console.log('>>> loadJS', url)
   buberStats.initQueue.push(url);
   var js=document.createElement("script");
   js.type="text/javascript";
   js.onload=js.onreadystatechange=function(){
      if(this.readyState && this.readyState=="loading") return; //IEfix
      if(cb) cb(url, js);
      buberStats.initQueue.splice(buberStats.initQueue.indexOf(url), 1);
  }
   js.onerror=function(){
      console.log('!!!ERROR_buberStats loading some resources failed', url);
   }
   js.charset='utf-8';
   js.src=url;
   document.getElementsByTagName("head")[0].appendChild(js);
}

buberStats.init=function(){
   // if(buberStats.debug) return console.log('BuberStats DISABLED by url');
   if(buberStats.inited) return false;
   buberStats.inited=true;
   // console.log('Loading...');
   if(!window.functionsEx.version)
      buberStats.loadJs('//buber.ru/js/functionsex.js', function(){functionsEx.importNow(buberStats, {'funcs':true, 'vars':true})});
   else if(!buberStats.functionsex_imported_into_scope)
      functionsEx.importNow(buberStats, {'funcs':true, 'vars':true});
   if(!window.Sizzle && !window.jQuery) buberStats.loadJs('//buber.ru/js/sizzle_fixed.min.js');
   if(!window.JSON) buberStats.loadJs('//buber.ru/js/json3.min.js');
   // if(!window.jQuery) buberStats.loadJs('//code.jquery.com/jquery-1.8.3.min.js');
   if(!buberStats.initQueue.length && buberStats.functionsex_imported_into_scope){
      buberStats.inited=true; //! fix от бага когда buberStats.init() вызывается несколько раз и при этом перетирается buberStats.init. Проявляется очень редко
      buberStats.statsLoad();
   }else buberStats.initTimer=setInterval(function(){
      buberStats.inited=true; //fix от бага когда buberStats.init() вызывается несколько раз и при этом перетирается buberStats.init. Проявляется очень редко
      if(buberStats.initQueue.length || !buberStats.functionsex_imported_into_scope) {
         if(buberStats.debug) console.log('Buber.Stats: ждем initQueue');
         return;
      }
      clearInterval(buberStats.initTimer);
      buberStats.statsLoad();
   }, 300);
}

buberStats.loadModule=function(m){
   if(m=='iseeyou' && !window.iseeyou)
      buberStats.loadJs('//ad.buber.ru/iseeyou/js/iseeyou.js');
}

buberStats.statsLoad=function(){
   if (buberStats.completed) return false;
   buberStats.completed=true;
   buberStats.inited=true; //fix от бага когда buberStats.init() вызывается несколько раз и при этом перетирается buberStats.init. Проявляется очень редко
   if(!!parseInt(buberStats.lHash.get('useDebugApi')))  //заменяем апи на тестовую
      buberStats.serverAdress=buberStats.serverAdressDebug;
   if(window.addEventListener) window.addEventListener("message", buberStats.buberPostListener, false);
   else window.attachEvent("onmessage", buberStats.buberPostListener);
   if(buberStats.disabled) return;
   // iseeyou
   if(!buberStats.isIframe()){
      if(window.buber_force_iseeyou || 'iseeyou' in buberStats.parseURL2(document.referrer).params){
         if(!('iseeyou' in buberStats.parseURL2().params))
            history.pushState(null, '', (window.location.search|| '?')+'&iseeyou=1'+window.location.hash);
      }
      if('iseeyou' in buberStats.parseURL2().params)
         buberStats.loadModule('iseeyou');
   }
   //разбираемся с формами
   if(buberStats.processForms==true || _buber['processForm']==true){
      buberStats.domReady(buberStats.formEvents);
   }
   // buberStats.printOnly('Initing Buber.Stats...');
   //загрузка сайта
   _buber['href'] = encodeURIComponent(buberStats.url);
   _buber['ref'] = encodeURIComponent(document.referrer);
   _buber['iframed'] = buberStats.isIframe();
   _buber['userAgent'] = encodeURIComponent(window.navigator.userAgent);
   _buber['userAgentLang'] = encodeURIComponent(window.navigator.language);
   _buber['width'] = encodeURIComponent(screen.width);
   _buber['height'] = encodeURIComponent(screen.height);
   _buber['mtime'] = encodeURIComponent(new Date().getTime());
   _buber['pageSess'] = functionsEx.proto_str.hashCode(_buber['href']+''+_buber['mtime']);
   _buber['formData']= [];
   _buber['clickData']=[];
   _buber['session']=buberStats.getCookie('_buberSess');
   _buber['ABTesting_flag']=buberStats.getCookie('_buberABTest_flag');
   _buber['ABTesting_flag']=_buber['ABTesting_flag']? JSON.parse(_buber['ABTesting_flag']): {};
   _buber['orderData']=(JSON.stringify(_buber['order'])||'')
   buberStats.hostname=window.top.location.hostname|| window.self.location.hostname;
   buberStats.domain=buberStats.hostname;
   if (buberStats.crossSubDomains && buberStats.hostname.split('.').length>2) //обрезаем поддомен в случае если нужна кросдоменная обработка
      buberStats.domain=buberStats.hostname.split('.').slice(buberStats.hostname.split('.').length-2).join('.');
   if(!_buber['session']){
      _buber['session'] = functionsEx.proto_str.hashCode(_buber['mtime']+' '+_buber['pageSess']);
      document.cookie="_buberSess="+_buber['session']+"; path=/;domain="+buberStats.domain;
   }
   if(!_buber['__buberWatch']) {
      _buber['__buberWatch']=buberStats.getCookie('__buberWatch'); //тут есть шанс получить из куки
      if (window.buberCall) buberCall['userSha']=_buber['__buberWatch']; //передаём в buberCall
   }
   //даже если удалось получить, всеравно вызываем метод getUserSha() чтобы он установил глобальную куку
   //существующий buberWatch также передается, чтобы не генерировать новый без необходимости
   _buber['__buberWatch']=_buber['__buberWatch']|| '';
   var data=buberStats.forMe(['href', 'ref', 'iframed', 'userAgent', 'userAgentLang', 'width', 'height', 'mtime', 'pageSess', 'session', '__buberWatch'], function(k){return k+'='+_buber[k]}, null, true).join('&');
   var uid=functionsEx.proto_str.format('%s|%s|%s', functionsEx.proto_str.hashCode(buberStats.url), new Date().getTime(), buberStats.uuid.v4());
   buberStats.getUserSha(data, uid, !Boolean(_buber['__buberWatch']));
   var intervalID=setInterval(function(){
      if(!_buber['__buberWatch']) { //ждем userSha
         if (buberStats.debug) buberStats.printOnly('Buber.Stats: ждем __buberWatch');
         return;
      }
      clearInterval(intervalID);
      var postData='{"jsonrpc": "2.0", "method": "addSession", "params": [%s], "id":'+Math.round(Math.random()*65536)+'}';
      _buber.checkABTesting=true;
      postData=functionsEx.proto_str.format(postData, JSON.stringify(_buber));
      _buber.checkABTesting=undefined;
      buberStats.ajaxMe(buberStats.serverAdress.statsApi[Number(buberStats.isSSL)], function(res){
            if (buberStats.debug) buberStats.printOnly('addsession_res',res);
            res=JSON.parse(res);
            res=res.result;
            if(res.status!==1) buberStats.printOnly('Buber.Stats: error data');
            if(buberStats.debug) buberStats.printOnly('Buber.Stats: success');
            var serverTime=[res.time, buberStats.getms(false)];
            if(res.status && buberStats.isObject(res.abTesting)) //запуск ABTest
               buberStats.domReady(function(){buberStats.runABTesting(res.abTesting, serverTime)});
      }, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
      buberStats.closeSession(buberStats.closeSession.repeat);  //откладываем ближайший вызов closeSession на заданное значение repeat (поумолчанию 10сек), а дальше она сама себя будет вызывать разруливая конфликты повторных вызовов чаще чем раз в секунду
      buberStats.catchTripleClick();
      //запрос на тестовый сервер
      // var postData=functionsEx.proto_str.format('{"jsonrpc": "2.0", "method": "addSession", "params": [%s]}', JSON.stringify(_buber));
      // buberStats.ajaxMe((buberStats.isSSL? 'https://s2.buber.ru:6011/statsApi_test': 'http://s2.buber.ru:6001/statsApi_test'), function(res){}, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
   },1000);
}

buberStats.formEvents=function(){
   //обрабатываем все инпуты и селекты
   buberStats.forMe(['input', 'textarea', 'select'], function(type){
      buberStats.forMe(document.getElementsByTagName(type), function(o){
         if(o.getAttribute('__buber_listener_enabled')) return;
         o.setAttribute('__buber_listener_enabled', true);
         // first of all, we dumps predefined values
         buberStats.formEvents.dumpElem(o, type);
         // now, connecting event listeners
         var isOk=true;
         buberStats.forMe({
            'change':buberStats.formEvents.cb,
            'keyup':buberStats.formEvents.cb,
            'input':buberStats.formEvents.cb,
            'propertychange':function(ev){if(ev.propertyName=='value') buberStats.formEvents.cb(ev)},
            'cut':function(ev){setTimeout(function(){buberStats.formEvents.cb(ev)}, 0)},
         }, function(event, cb){
            if(o.addEventListener) o.addEventListener(event, cb);
            else if(o.attachEvent) o.attachEvent('on'+event, cb);
            else isOk=false;
         })
      })
   })

   // var postElemData=function(elem){
   //    //собираем данные элемента и постим их на апишку
   //    var name=elem.getAttribute('name'), id=elem.getAttribute('id'), val=elem.value;
   //    var opt=undefined;
   //    if(!val) return; //не отправляем, если пустышка
   //    //обработка селектов
   //    if(elem.nodeName.toLowerCase()==='select' && elem.selectedIndex==-1) opt='';
   //    else if(elem.type==='select-one' || elem.type==='select-multiple')
   //       //! костыль, апишка не поддерживает множественные селекты. как будет поддержка ,нужно убрать вторую проверку, код ниже корректно обрабатывает мульти-селекты
   //       opt=elem.options[elem.selectedIndex].text;
   //    // else if(elem.type==='select-multiple'){
   //    //    opt=[], val=[];
   //    //    buberStats.forMe(elem.length, function(i){
   //    //       if(!elem.options[i].selected) return;
   //    //       opt.push(elem.options[i].text);
   //    //       val.push(elem.options[i].value);
   //    //    });
   //    // }
   //    //отправка
   //    buberStats.postForm(name, id, val, opt);
   // }
   // //вешаем события на елементы по типу
   // buberStats.forMe(['input', 'textarea', 'select', 'form', 'button'], function(t){
   //    buberStats.forMe(document.getElementsByTagName(t), function(e){
   //       if(t==='form' && e.id==='buberForm') return;
   //       if(t==='input' && e.type==='hidden') return;
   //       //проверка, обработан ли уже элемент
   //       if(e.getAttribute('__buber_listener_enabled')) return;
   //       e.setAttribute('__buber_listener_enabled', true);
   //       //выбор события и коллбека
   //       var ev=null, cb=null;
   //       if(t==='form'){
   //          ev='submit';
   //          cb=function(event){
   //             return;  // вызывает проблемы, отказываемся от такого способа сбора данных

   //             var ths=this;
   //             if(cb.paused){
   //                cb.paused=false;
   //                return;
   //             }
   //             event.preventDefault(); // reject submitting
   //             //обрабатываем все вложенные элементы по типу
   //             buberStats.forMe(['input', 'textarea', 'select'], function(t){
   //                buberStats.forMe(ths.getElementsByTagName(t), postElemData);
   //             })
   //             cb.paused=true;
   //             buberStats.closeSession(function(){
   //                if(ths.submit && buberStats.isFunction(ths.submit)) ths.submit()
   //                else if (ths.submit && ths.submit.click && buberStats.isFunction(ths.submit.click)) ths.submit.click()
   //                else
   //                   buberStats.printOnly('Buber.Stats: Cant continue form submitting for', ths);
   //             }); //отправляем на api и возобновляем form submitting
   //          }
   //       }
   //       else{
   //          ev='change';
   //          cb=function(){postElemData(this)};
   //       }
   //       //навешивание
   //       if(e.addEventListener) e.addEventListener(ev, cb, true);
   //       else if(e.attachEvent) e.attachEvent('on'+ev, cb);
   //    })
   // })
   //планируем повторный вызов по таймауту
   setTimeout(buberStats.formEvents, 3000);
}

buberStats.formEvents.dumpElem=function(o, type){
   type=type|| o.tagName.toLowerCase();
   var predef=null;
   if(type==='input' && (o.type==='checkbox' || o.type==='radio')) predef=o.checked? true: null;
   else if(type==='input' || type==='textarea') predef=o.value;
   else if(type==='select'){
      predef=buberStats.forMe(o.options, function(o2){
         if(o2.selected) return o2.value|| o2.text;
      }, null, true);
      predef=predef.length? predef: null;
   }
   if(predef)
      buberStats.postForm(o.name, o.id, o.value, predef);
}

buberStats.formEvents.cb=function(ev){
   var o=ev.target;
   buberStats.formEvents.dumpElem(o);
}

buberStats.fireEvent=function(obj, evt){
     if( document.createEvent ) {
       var evObj = document.createEvent('MouseEvents');
       evObj.initEvent( evt, true, false );
       obj.dispatchEvent( evObj );
     }
      else if( document.createEventObject ) { //IE
       var evObj = document.createEventObject();
       obj.fireEvent( 'on' + evt, evObj );
     }
}

if(buberStats.processClicks==true){
   window.onclick=function(event){
      if (buberStats.processClicks==false) return true;
      //событие на клик по элементу
      event = event || window.event
      var t = event.target || event.srcElement;
      var xpath = buberStats.getXPath(t);
      buberStats.postEvent(t.tagName,t.getAttribute('name'), t.getAttribute('id'), xpath, t.innerText, t.getAttribute('href'));
   }
}

buberStats.postForm=function(name, id, value, option){
   _buber['formData']=_buber['formData']|| [];
   var formData={'formName':name, 'formId':id, 'formValue':value, 'formOption':option, 'mktime':new Date().getTime()};
   _buber['formData'].push(formData);
   buberStats.closeSession();
}

buberStats.postEvent=function(tagName, name, id, xpath, text, href){
   _buber['clickData']=_buber['clickData']|| [];
   var clickData={'tagName':tagName, 'name':name, 'id':id, 'xpath':xpath, 'mktime':new Date().getTime(), 'text':text,'href':href}
   _buber['clickData'].push(clickData);
}

buberStats.postTransaction=function(orderData){
   buberStats.printOnly('Buber.Stats - postTransaction');
   var intervalID=setInterval(function(){
      if(!_buber['__buberWatch']) { //ждем userSha
         if (buberStats.debug) buberStats.printOnly('Buber.Stats: ждем __buberWatch');
         return;
      }
      clearInterval(intervalID);
      var params={
         'orderData':(JSON.stringify(orderData)||''),
         'pageSess':encodeURIComponent(_buber['pageSess']),
         'session':encodeURIComponent(_buber['session']),
         'closeTime':encodeURIComponent(_buber['closeTime']),
         'formData':(JSON.stringify(_buber['formData'])),
         'clickData':(JSON.stringify(_buber['clickData'])),
         '__buberWatch':_buber['__buberWatch']
      }
      var postData='{"jsonrpc": "2.0", "method": "postData", "params": [%s], "id":'+Math.round(Math.random()*65536)+'}';
      postData=functionsEx.proto_str.format(postData, JSON.stringify(params));
      if (buberStats.debug) buberStats.printOnly(postData);
      buberStats.ajaxMe(buberStats.serverAdress.statsApi[Number(buberStats.isSSL)], function(res){
            if (buberStats.debug) buberStats.printOnly('res',res);
            res=JSON.parse(res);
            res=res.result;
            if(res.status!==1) buberStats.printOnly('Buber.Stats: error closeSession');
            if (buberStats.debug) buberStats.printOnly('Buber.Stats: close success');
            _buber['formData'] = [] //очищаем данные
            _buber['clickData'] = [] //очищаем данные
      }, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
      //запрос на тестовый сервер
      try{
         // var postData=functionsEx.proto_str.format('{"jsonrpc": "2.0", "method": "postData", "params": [%s]}', JSON.stringify(params));
         // buberStats.ajaxMe((buberStats.isSSL? 'https://s2.buber.ru:6011/statsApi_test': 'http://s2.buber.ru:6001/statsApi_test'), function(res){}, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
      }catch(e){}
   },1000);
}

function postTransaction(orderData){ //старая версия
   buberStats.postTransaction(orderData);
}

buberStats.closeSession=function(delay){
   clearTimeout(buberStats.closeSession.timer);
   delay=delay!==undefined? delay: buberStats.closeSession.delay;
   buberStats.closeSession.timer=setTimeout(function(){
      clearTimeout(buberStats.closeSession.timer);
      if(!_buber['__buberWatch']) { //ждем userSha
         if (buberStats.debug && buberStats.printOnly)
            // теоретически этот вызов может произойти ДО подгрузки библиотек
            buberStats.printOnly('Buber.Stats: ждем __buberWatch');
         buberStats.closeSession.timer=setTimeout(buberStats.closeSession, buberStats.closeSession.repeat);
         return;
      }
      _buber['closeTime'] = new Date().getTime();
      var params={
         'href':encodeURIComponent(buberStats.url),
         'pageSess':encodeURIComponent(_buber['pageSess']),
         'session':encodeURIComponent(_buber['session']),
         'closeTime':encodeURIComponent(_buber['closeTime']),
         '__buberWatch':_buber['__buberWatch']
      }
      if(_buber['formData'].length>0)
         params['formData']=(JSON.stringify(_buber['formData']));
      if(_buber['clickData'].length>0)
         params['clickData']=(JSON.stringify(_buber['clickData']));
      _buber['formData']=[];
      _buber['clickData']=[];
      var postData='{"jsonrpc": "2.0", "method": "closeSession", "params": [%s], "id":'+Math.round(Math.random()*65536)+'}';
      postData=functionsEx.proto_str.format(postData, JSON.stringify(params));
      if (buberStats.debug) buberStats.printOnly(postData);
      buberStats.ajaxMe(buberStats.serverAdress.statsApi[Number(buberStats.isSSL)], function(res){
            clearTimeout(buberStats.closeSession.timer);
            buberStats.closeSession.timer=setTimeout(buberStats.closeSession, buberStats.closeSession.repeat);
            if (buberStats.debug)
               buberStats.printOnly('closesession_res',res);
            res=JSON.parse(res);
            res=res.result;
            if(res.status!==1)
               buberStats.printOnly('Buber.Stats: error closeSession');
            if (buberStats.debug)
               buberStats.printOnly('Buber.Stats: close success');
            // document.forms[0].submit.click();
      }, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
   }, delay);
}
buberStats.closeSession.repeat=10000;
buberStats.closeSession.delay=1000;

window.onbeforeunload=function(e){
   buberStats.closeSession();
}

buberStats.reciveMessage=function(e){
   var sender=e.source;
   var data=e.data;
   var origin=e.origin;
   var res={};
   // console.log('!! Recived message', data)
   try{data=JSON.parse(data);}
   catch(e){
      // console.log('!!!ERROR recived bad data', e);
      return;
   }
   //обрабатываем запрос
   if(functionsEx.proto_arr.inOf(['ping'], data.what)) res.what='pong';
   else if(functionsEx.proto_arr.inOf(['DOMInspectorEnable'], data.what)){//включаем инспектор ДОМ дерева
      res.what='pong'
      //включаем инспектор
      var tFunc1=function tFunc1(){
         window.gogtg.on(function(elem){
            //здесь идет проверка на элементы, доступные для выбора
            if(data.checker){
               if(data.checker.tagName && !functionsEx.proto_arr.inOf(data.checker.tagName, elem.tagName.toLowerCase())) return false;
            }
            return true;
         });
         window.gogtg.clickCB=function(path, elem){
            sender.postMessage(JSON.stringify({'what':'DOMInspectorClicked', saved:false, path:path, 'id':data.id, 'mytime':buberStats.getms()}), '*');
         }
         window.gogtg.selectSavedCB=function(path, elem){
            sender.postMessage(JSON.stringify({'what':'DOMInspectorClicked', saved:true, path:path, 'id':data.id, 'mytime':buberStats.getms()}), '*');
         }
         sender.postMessage(JSON.stringify({'what':'DOMInspectorEnabled', 'id':data.id, 'mytime':buberStats.getms()}), '*');
      }
      //проверяем, загружен ли код инспектора
      if(!window.gogtg) buberStats.loadJs('//ad.buber.ru/js/goGadgetTwoGirls.js', tFunc1);
      else tFunc1();
      return;
   }else if(functionsEx.proto_arr.inOf(['DOMInspectorSave', 'DOMInspectorUnsave'], data.what)){
      if(data.what=='DOMInspectorSave') gogtg.save(data.path, data.border, data.scroll);
      else gogtg.unsave(data.path);
      res.what=data.what+'d';
   }else if(data.what=='DOMInspectorSerialize'){
      res.what='DOMInspectorSerialized';
      res.path=data.path;
      res.data=gogtg.domTools.serialize(data.path);
   }else if(data.what=='DOMInspectorReplace'){
      res.what='DOMInspectorReplaced';
      res.path=data.path;
      res.data=gogtg.domTools.replace(data.path, data.data);
   }else if(data.what=='DOMInspectorLoadCss'){
      res.what='DOMInspectorLoadedCss';
      res.path=data.path;
      buberStats.domTools.loadCss(data.path);
   }else if(data.what=='DOMInspectorUnloadCss'){
      res.what='DOMInspectorUnloadedCss';
      res.path=data.path;
      gogtg.domTools.unloadCss(data.path);
   }else return;
   //подготавливаем ответ
   if(!res.what) return;
   res.id=data.id;
   res.mytime=buberStats.getms();
   res.yourtime=data.mytime;
   res=JSON.stringify(res); //для поддержки IE8
   sender.postMessage(res, '*');
}

buberStats.buberPostListener=function(event){
//==это событие подписывается в buberStats.statsLoad() чтобы избежать конфликтов
   if(functionsEx.proto_arr.inOf(['http://buber.ru', 'https://buber.ru', 'http://stats.buber.ru', 'https://stats.buber.ru'], event.origin)){
      if(buberStats.debug) buberStats.printOnly('Buber.Stats: присваиваем userSha');
      _buber['__buberWatch']=event.data;
      if (window.buberCall) buberCall['userSha']=_buber['__buberWatch']; //передаём в buberCall
      document.cookie="__buberWatch="+_buber['__buberWatch']+"; path=/; expires=2147483647;";
      buberStats.userSha=true;
    }else buberStats.reciveMessage(event);
};

// buberStats.onload=function(handler){
//    var called=false;
//    function ready(){
//       if(called) return;
//       called=true;
//       handler();
//    }
//    if(document.addEventListener)
//       document.addEventListener("DOMContentLoaded", function(){ready()}, false);
//    else if(document.attachEvent){
//       if(document.documentElement.doScroll && window==window.top){
//          function tryScroll(){
//             if(called) return;
//             if(!document.body) return;
//             try{
//                document.documentElement.doScroll("left");
//                ready();
//             }catch(e){
//                setTimeout(tryScroll, 0);
//             }
//          }
//          tryScroll();
//       }
//       document.attachEvent("onreadystatechange", function(){
//          if(document.readyState==="complete") ready();
//       })
//    }
//    if(window.addEventListener) window.addEventListener('load', ready, false);
//    else if(window.attachEvent) window.attachEvent('onload', ready);
//    else window.onload=ready;
// }

// buberStats.onload(buberStats.init);

buberStats.init();

buberStats.runABTesting=function(data, serverTime){
   buberStats.printOnly('Start ABTesting..');
   _buber['ABTesting_flag']=_buber['ABTesting_flag']|| {};
   buberStats.forMe(data, function(id, actionArr){
      buberStats.forMe((buberStats.isArray(actionArr)? actionArr: [actionArr]), function(action){
         var elements=null;
         if(action.selector){
            var m=action.xpath? 'queryXpathAll': 'querySelectorAll';
            elements=buberStats.domTools[m](action.selector);
            if(!elements || !elements.length) return;
         }
         // вызов коллбека, если задан
         /*
         Вызываемый код имеет доступ к нескольким дополнительным переменным: <id>, <actionArr>, <action>, <elements>;
         Если код вернет False, текущий тест будет пропущен.
         В случае ошибки текущий тест будет пропущен.
         */
         if(action.js){
            try{
               if(eval(action.js)===false) return;
            }catch(err){
               var s=buberStats.format('Error in passed code of ABTesting[%s] <%s>: ', id, action.js);
               buberStats.printOnly(s, err);
               return;
            }
         }
         // применение теста
         if(action['type']==='style') buberStats.domTools.loadCss(action.value);
         else if(action['type']==='flag'){
            if(!_buber['ABTesting_flag'][id]) _buber['ABTesting_flag'][id]={};
            var n=action['name']|| '__', v=action['value'];
            if(functionsEx.proto_arr.inOf([null, undefined, ''], v))
               delete _buber['ABTesting_flag'][id][n];
            else
               _buber['ABTesting_flag'][id][n]=v;
         }else if(elements){
            if(action['type']==='html') buberStats.domTools.innerHtml(elements, action.value, 0);
            if(action['type']==='htmlAppend') buberStats.domTools.innerHtml(elements, action.value, 1);
            if(action['type']==='htmlPrepend') buberStats.domTools.innerHtml(elements, action.value, -1);
            if(action['type']==='class') buberStats.domTools.changeClass(elements, action.value, '*');
            if(action['type']==='classAdd') buberStats.domTools.changeClass(elements, action.value);
            if(action['type']==='classDel') buberStats.domTools.changeClass(elements, '', action.value);
            if(action['type']==='css') buberStats.domTools.changeCss(elements, action.value);
         }
      })
   })
   //! для http и https куки устанавливаются раздельно?
   document.cookie='_buberABTest_flag='+JSON.stringify(_buber['ABTesting_flag'])+"; path=/; expires=2147483647;";
}

buberStats.catchTripleClick=function(){
   var oldElem=null;
   var sendToApi=function(e, method){
      var target=e.target|| e.srcElement;
      if(oldElem===target) return;
      if(e.preventDefault) e.preventDefault();
      if(e.stopPropagation) e.stopPropagation();
      oldElem=target;
      setTimeout(function(){oldElem=null}, 50);
      var data={
         'href':_buber['href'], 'ref':_buber['ref'], 'iframed':_buber['iframed'], 'userAgent':_buber['userAgent'],
         'pageSess':encodeURIComponent(_buber['pageSess']), 'session':encodeURIComponent(_buber['session']),
         '__buberWatch':_buber['__buberWatch'],
         'mtime':_buber['mtime'], 'mytime':buberStats.getms(),
         'xPath':buberStats.getXPath(target), 'cssPath':buberStats.getCSSPath(target),
         'catchTripleClick_method':method
      };
      // buberStats.printOnly('<3CLICK>', data, e);
      var postData='{"jsonrpc": "2.0", "method": "tripleClick", "params": [%s], "id":'+Math.round(Math.random()*65536)+'}';
      postData=functionsEx.proto_str.format(postData, JSON.stringify(data));
      buberStats.ajaxMe(buberStats.serverAdress.statsApi[Number(buberStats.isSSL)], function(res){}, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
      // buberStats.ajaxMe('http://stats.buber.ru:8039/statsApi', function(res){}, 'post', postData, {'Content-Type':'application/x-www-form-urlencoded'});
   };
   //for old browsers
   var catch_fallback=function(){
      if(buberStats.catchTripleClick.enabled) return;
      buberStats.catchTripleClick.enabled=true;
      var mytimer;
      var cb1=function(e){
         mytimer=setTimeout(function(){mytimer=null}, 50);
      }
      var cb2=function(e){
         if(!mytimer) return;
         clearTimeout(mytimer);
         mytimer=null;
         sendToApi(e, 'fallback');
      }
      var method=window.addEventListener? 'addEventListener': 'attachEvent';
      var prefix=window.addEventListener? '': 'on';
      var all=document.body.getElementsByTagName("*");
      buberStats.forMe(all, function(elem){
         if(functionsEx.proto_arr.inOf(['script', 'iframe'], elem.tagName.toLowerCase())) return;
         elem[method](prefix+'dblclick', cb1, true);
         elem[method](prefix+'click', cb2, true);
      })
      // window[method](prefix+'dblclick', cb1, true);
      // window[method](prefix+'click', cb2, true);
      // buberStats.printOnly(">>>>TripleClicks capture [fallback]<<<<", buberStats.isIframe());
   }
   //for modern browsers
   var catch_modern=function(){
      if(buberStats.catchTripleClick.enabled) return;
      buberStats.catchTripleClick.enabled=true;
      var cb=function(e){
         if(functionsEx.proto_arr.inOf([null, undefined], e.detail)){ //unsupported
            setTimeout(function(){
               var all=document.body.getElementsByTagName("*");
               buberStats.forMe(all, function(elem){
                  if(functionsEx.proto_arr.inOf(['script', 'iframe'], elem.tagName.toLowerCase())) return;
                  elem.removeEventListener('click', cb);
               })
               // window.removeEventListener('click', cb);
               buberStats.catchTripleClick.enabled=false;
               catch_fallback();
            }, 0);
         }else if(e.detail===3) sendToApi(e, 'modern');
      }
      var all=document.body.getElementsByTagName("*");
      buberStats.forMe(all, function(elem){
         if(functionsEx.proto_arr.inOf(['script', 'iframe'], elem.tagName.toLowerCase())) return;
         elem.addEventListener('click', cb, true);
      })
      // window.addEventListener('click', cb, true);
      // buberStats.printOnly(">>>>TripleClicks capture [modern]<<<<", buberStats.isIframe());
   }
   //try to select mode
   if(!window.addEventListener && !window.attachEvent)
      return;// buberStats.printOnly('BuberStats: cant handle triple-clicks!');
   else if(window.addEventListener) catch_modern();
   else catch_fallback();
}

/*============================================================*/
buberStats.domTools={};

buberStats.domTools.querySelectorAll=function(selector){
   //! У document.querySelectorAll ограничен синтаксис, придется использовать ненативные реализации
   if(window.Sizzle) return window.Sizzle(selector);
   else if(window.jQuery) return window.jQuery(selector);
   else{
      buberStats.printOnly('!!!ERROR_adWolf sizzle engine not found');
      return null;
   }
}

buberStats.domTools.queryXpathAll=function(selector){
   var tArr=[];
   var iter=document.evaluate(selector, document, null, XPathResult.ANY_TYPE, null);
   while(true){
      var o=iter.iterateNext();
      if(!o) break;
      tArr.push(o);
   }
   return tArr;
}

buberStats.domTools.innerHtml=function(o, data, order){
   buberStats.forMe((buberStats.isArray(o) || buberStats.isJquery(o)? o: [o]), function(oo){
      oo=buberStats.isJquery(oo)? oo[0]: oo;
      // http://domscripting.com/blog/display/99
      var newdiv=document.createElement("div");
      newdiv.innerHTML=data;
      if(order>0)  //добавляет в конец блока
         oo.appendChild(newdiv.firstChild);
      else if(order<0)  //добавляет в начало блока
         oo.insertBefore(newdiv.firstChild, oo.firstChild);
      else{  //заменяет контент блока
         while(oo.firstChild) oo.removeChild(oo.firstChild);
         oo.appendChild(newdiv.firstChild);
      }
   })
}

buberStats.domTools.changeClass=function(o, add, del){
   buberStats.forMe((buberStats.isArray(o) || buberStats.isJquery(o)? o: [o]), function(oo){
      oo=buberStats.isJquery(oo)? oo[0]: oo;
      var classNew=buberStats.isString(add)? add: add.join(' ');
      var classOld=oo.className;
      if(classOld) classOld=classOld.split(' ');
      if(del && del!=='*'){
         if(classOld) buberStats.forMe((buberStats.isArray(del)? del: [del]), function(s){
            classOld=functionsex.proto_arr.delex(classOld, s);
         })
      }
      if(classOld && classOld.length) classNew=classOld.join(' ')+' '+classNew;
      oo.className=classNew;
   })
}

buberStats.domTools.changeCss=function(o, data){
   buberStats.forMe((buberStats.isArray(o) || buberStats.isJquery(o)? o: [o]), function(oo){
      oo=buberStats.isJquery(oo)? oo[0]: oo;
      //! Возможно стоит добавить более полную обработку, проход по всему списку и замену сущестующих
      oo.style.cssText+=buberStats.isString(data)? data: data.join('; ');
   })
}

buberStats.domTools.loadCss=function(urlArr){
   urlArr=buberStats.isArray(urlArr)? urlArr: [urlArr];
   buberStats.forMe(urlArr, function(url){
      var style=document.createElement("link");
      style.id=functionsEx.proto_str.hashCode(url);
      style.className='buberStats';
      style.rel="stylesheet";
      style.type="text/css";
      style.href=url;
      document.getElementsByTagName("head")[0].appendChild(style);
   })
}

