$(document).ready(function(){
    
   slider = $('.carousel').slick();

    
   $(window).scroll(function (event) {
            var scroll = $(window).scrollTop();
                        
            if(scroll<500){
                $(".menu__option").removeClass("menu__option-active");
                
            }else if(scroll>=500 && scroll<1220){
                $(".menu__option").removeClass("menu__option-active");
                $(".menu1").addClass("menu__option-active");
                
            }else if(scroll>=1220 && scroll<1955){
                $(".menu__option").removeClass("menu__option-active");
                $(".menu2").addClass("menu__option-active");
                     
            }else if(scroll>=1955){
                $(".menu__option").removeClass("menu__option-active");
                $(".menu3").addClass("menu__option-active");
                
            }
        });
});


/* header */

    function logoClick(){
        $('html, body').animate({
            scrollTop: $(".first-block").offset().top - 140
        }, 600);
        
    }

    function goLk(){

        window.location.href = "login/";
        
    }
    function menu1(){
        $('html, body').animate({
            scrollTop: $(".second-block").offset().top - 140
        }, 600);
        
    }
    function menu2(){
        $('html, body').animate({
            scrollTop: $(".third-block").offset().top - 115
        }, 600);
        
    }
    function menu3(){
        $('html, body').animate({
            scrollTop: $(".fourth-block").offset().top - 135
        }, 600);
        
    }

/* header end */



/* Mobile button scrolltop */

    function scrollTop() {
        $('html, body').animate({
            scrollTop: 0
        }, 600);
        
    }

/* Mobile button scrolltop end */

/* First block */

    function goReg(){

        window.location.href = "reg/";
    }

/* First block end */

/* Third block */

    function openModal() {
        
        
        $(".mobile-scroll-top-button").hide();
        
        $(".header-menu").hide();
                        
        $(".slider-modal").css("height", "100%");
        
        $("body").css("overflow", "hidden");
        
        slider.slick("slickSetOption", "draggable", false, false);

    }

    function closeModal() {
        $(".header-menu").show();
            
        $(".slider-modal").css("height", "0%");
        
        $("body").css("overflow", "auto");


    }


/* Third block end */



   
/* footer */

    function vkClick(){
        window.open("https://vk.com/returner_ru", "_blank");
    }
    
    function fbClick(){
        window.open("https://www.facebook.com/returner.ru", "_blank");    
    }

/* footer end */