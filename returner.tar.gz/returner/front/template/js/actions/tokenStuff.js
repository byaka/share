import { store } from '../../js/store';

export function addToken( token ) {
    
    store.dispatch({type: 'ADDTOKEN', token: token })
    
}


 

